(function(){
  const DB_KEY = 'crm_whatsapp_local_v2';
  const WEEK_DAYS = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const DAY_SHORT = ['DOM','LUN','MAR','MIÉ','JUE','VIE','SÁB'];
  const DEFAULT_SETTINGS = {
    base: { name:'Base operativa', address:'Avenida Cantábrico 15, Arroyomolinos, Madrid' },
    blockedWeekdays: [5,0],
    workWindows: {
      1:[{start:'09:00',end:'14:00'},{start:'16:00',end:'19:00'}],
      2:[{start:'09:00',end:'14:00'},{start:'16:00',end:'19:00'}],
      3:[{start:'09:00',end:'14:00'},{start:'16:00',end:'19:00'}],
      4:[{start:'09:00',end:'14:00'},{start:'16:00',end:'19:00'}],
      5:[],
      6:[{start:'10:00',end:'13:00'}],
      0:[]
    },
    zones: {
      CENTRO:{name:'Madrid Centro', road:'M-30 / A-5', km:28, travel:36, preferred:'mañana', section:'Mañana urbana'},
      NORTE:{name:'Norte', road:'A-1 / M-607', km:43, travel:48, preferred:'mañana', section:'Mañana norte'},
      ESTE:{name:'Este', road:'A-2 / M-45', km:49, travel:52, preferred:'tarde', section:'Tarde este'},
      SUR:{name:'Sur', road:'A-4 / A-42', km:34, travel:40, preferred:'tarde', section:'Tarde sur'},
      OESTE:{name:'Oeste', road:'A-5 / A-6', km:22, travel:30, preferred:'mañana', section:'Bloque oeste'}
    },
    serviceTypes: {
      'Instalación inicial':150,
      'Mantenimiento mensual':90,
      'Revisión técnica':75,
      'Entrega / recogida':60,
      'Urgencia':120,
      'Consultoría presencial':105
    }
  };

  const SAMPLE_CONTACTS = [
    {id:'c_ana', name:'Ana Beltrán', phone:'600111222', email:'ana.beltran@mail.com', company:'Particular', address:'Calle Alcalá 110, Madrid', zone:'CENTRO', source:'WhatsApp', createdAt:'2026-05-01'},
    {id:'c_luis', name:'Luis Heredia', phone:'600222333', email:'luis@heredia.es', company:'Heredia SL', address:'Paseo de la Castellana 210, Madrid', zone:'NORTE', source:'Web', createdAt:'2026-05-02'},
    {id:'c_sara', name:'Sara Montero', phone:'600333444', email:'sara.montero@mail.com', company:'Montero Studio', address:'Avenida de América 42, Madrid', zone:'ESTE', source:'Referido', createdAt:'2026-05-03'},
    {id:'c_david', name:'David Rivas', phone:'600444555', email:'david.rivas@mail.com', company:'Particular', address:'Getafe Centro', zone:'SUR', source:'WhatsApp', createdAt:'2026-05-04'},
    {id:'c_elena', name:'Elena Sanz', phone:'600555666', email:'elena@empresa.es', company:'Sanz Retail', address:'Pozuelo de Alarcón', zone:'OESTE', source:'LinkedIn', createdAt:'2026-05-05'},
    {id:'c_marta', name:'Marta Iglesias', phone:'600666777', email:'marta.iglesias@mail.com', company:'Particular', address:'Alcobendas', zone:'NORTE', source:'WhatsApp', createdAt:'2026-05-07'},
    {id:'c_pablo', name:'Pablo Torres', phone:'600777888', email:'pablo@torres.es', company:'Torres Consulting', address:'Leganés', zone:'SUR', source:'Google Ads', createdAt:'2026-05-08'}
  ];

  const SAMPLE_SERVICES = [
    {id:'s_1001', contactId:'c_ana', type:'Revisión técnica', zone:'CENTRO', duration:75, priority:'media', status:'Planificado', requestedDate:'2026-05-11', preferredWindow:'mañana', notes:'Revisión de contrato y estado del servicio.', createdAt:'2026-05-01'},
    {id:'s_1002', contactId:'c_luis', type:'Instalación inicial', zone:'NORTE', duration:150, priority:'alta', status:'Planificado', requestedDate:'2026-05-12', preferredWindow:'mañana', notes:'Instalación completa. Acceso por garaje.', createdAt:'2026-05-02'},
    {id:'s_1003', contactId:'c_sara', type:'Mantenimiento mensual', zone:'ESTE', duration:90, priority:'media', status:'Planificado', requestedDate:'2026-05-13', preferredWindow:'tarde', notes:'Cliente prefiere última hora.', createdAt:'2026-05-03'},
    {id:'s_1004', contactId:'c_david', type:'Entrega / recogida', zone:'SUR', duration:60, priority:'baja', status:'Pendiente', requestedDate:'2026-05-14', preferredWindow:'tarde', notes:'Llamar 30 min antes.', createdAt:'2026-05-04'},
    {id:'s_1005', contactId:'c_elena', type:'Consultoría presencial', zone:'OESTE', duration:105, priority:'alta', status:'Planificado', requestedDate:'2026-05-15', preferredWindow:'mañana', notes:'Fecha objetivo cae viernes; debe moverse automáticamente.', createdAt:'2026-05-05'},
    {id:'s_1006', contactId:'c_marta', type:'Mantenimiento mensual', zone:'NORTE', duration:90, priority:'media', status:'Pendiente', requestedDate:'2026-05-18', preferredWindow:'mañana', notes:'Agrupar con ruta norte si es posible.', createdAt:'2026-05-07'},
    {id:'s_1007', contactId:'c_pablo', type:'Urgencia', zone:'SUR', duration:120, priority:'urgente', status:'Pendiente', requestedDate:'2026-05-11', preferredWindow:'tarde', notes:'Alta prioridad comercial.', createdAt:'2026-05-08'}
  ];

  function clone(x){ return JSON.parse(JSON.stringify(x)); }
  function uid(prefix){ return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7); }
  function minFromTime(time){ const [h,m] = time.split(':').map(Number); return h*60+m; }
  function timeFromMin(min){ const h = String(Math.floor(min/60)).padStart(2,'0'); const m = String(min%60).padStart(2,'0'); return `${h}:${m}`; }
  function iso(date){ return date.toISOString().slice(0,10); }
  function parseDate(str){ const [y,m,d] = String(str).split('-').map(Number); return new Date(y,m-1,d); }
  function addDays(date,n){ const d = new Date(date); d.setDate(d.getDate()+n); return d; }
  function todayIso(){ return '2026-05-11'; }
  function priorityScore(p){ return {urgente:0,alta:1,media:2,baja:3}[String(p||'media').toLowerCase()] ?? 2; }

  function getDB(){
    let db = null;
    try{ db = JSON.parse(localStorage.getItem(DB_KEY)); }catch(e){ db = null; }
    if(!db){ db = seedDB(); }
    return db;
  }
  function saveDB(db){ localStorage.setItem(DB_KEY, JSON.stringify(db)); }
  function seedDB(){
    const db = { settings: clone(DEFAULT_SETTINGS), contacts: clone(SAMPLE_CONTACTS), services: clone(SAMPLE_SERVICES), logs: [] };
    planAll(db, true);
    db.logs.unshift({ts:new Date().toISOString(), type:'Sistema', text:'CRM de ejemplo cargado y calendario planificado sin viernes.'});
    localStorage.setItem(DB_KEY, JSON.stringify(db));
    return db;
  }
  function resetDemo(){ localStorage.removeItem(DB_KEY); seedDB(); location.reload(); }

  function contactById(db,id){ return db.contacts.find(c=>c.id===id); }
  function zoneInfo(db,zone){ return db.settings.zones[zone] || db.settings.zones.CENTRO; }
  function isBlocked(db,date){ return (db.settings.blockedWeekdays || []).includes(date.getDay()); }
  function windowsFor(db,date){ return db.settings.workWindows[date.getDay()] || []; }

  function normalizeZone(raw){
    const x = String(raw||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
    if(x.includes('NORTE') || x.includes('ALCOB') || x.includes('A-1') || x.includes('M-607')) return 'NORTE';
    if(x.includes('ESTE') || x.includes('A-2') || x.includes('COSL') || x.includes('ALCALA')) return 'ESTE';
    if(x.includes('SUR') || x.includes('GETAFE') || x.includes('LEGAN') || x.includes('A-4') || x.includes('A-42')) return 'SUR';
    if(x.includes('OESTE') || x.includes('POZUELO') || x.includes('MAJAD') || x.includes('A-5') || x.includes('A-6')) return 'OESTE';
    return 'CENTRO';
  }
  function normalizePriority(raw){
    const x = String(raw||'media').toLowerCase();
    if(x.includes('urgent')) return 'urgente';
    if(x.includes('alta')) return 'alta';
    if(x.includes('baja')) return 'baja';
    return 'media';
  }
  function normalizeWindow(raw, zone){
    const x = String(raw||'').toLowerCase();
    if(x.includes('tarde')) return 'tarde';
    if(x.includes('mañana') || x.includes('manana')) return 'mañana';
    return zone==='ESTE' || zone==='SUR' ? 'tarde' : 'mañana';
  }
  function durationFromType(db, rawType, rawDuration){
    if(rawDuration){
      const m = String(rawDuration).match(/(\d+)/);
      if(m) return Number(m[1]);
    }
    const type = String(rawType || '').trim();
    const found = Object.keys(db.settings.serviceTypes).find(k => k.toLowerCase() === type.toLowerCase());
    return found ? db.settings.serviceTypes[found] : 90;
  }

  function extractLabel(text, labels){
    for(const label of labels){
      const re = new RegExp(`${label}\\s*[:=-]\\s*([^\n,;]+)`, 'i');
      const m = text.match(re);
      if(m) return m[1].trim();
    }
    return '';
  }
  function parseWhatsApp(text){
    const phone = extractLabel(text, ['Tel[eé]fono','Telefono','M[oó]vil','Movil','Phone','Número','Numero']);
    const name = extractLabel(text, ['Nombre','Cliente','Contacto','Name']);
    const email = extractLabel(text, ['Email','Correo']);
    const service = extractLabel(text, ['Servicio','Service','Contrataci[oó]n','Contratacion']);
    const address = extractLabel(text, ['Direcci[oó]n','Direccion','Ubicaci[oó]n','Ubicacion','Address']);
    const zoneRaw = extractLabel(text, ['Zona','Zone','Área','Area']);
    const date = extractLabel(text, ['Fecha objetivo','Fecha','D[ií]a','Dia']);
    const pref = extractLabel(text, ['Preferencia','Horario','Franja']);
    const priority = extractLabel(text, ['Prioridad','Priority']);
    const duration = extractLabel(text, ['Duraci[oó]n','Duracion','Duration']);
    const notes = extractLabel(text, ['Notas','Nota','Observaciones']);
    const road = extractLabel(text, ['Carretera','Ruta','Road']);
    const zone = normalizeZone(zoneRaw || road || address);
    return { name, phone: phone.replace(/\s+/g,''), email, service, address, zone, requestedDate: date || todayIso(), preferredWindow: normalizeWindow(pref, zone), priority: normalizePriority(priority), durationRaw: duration, notes, road };
  }
  function validateLead(lead){
    const errors = [];
    if(!lead.name) errors.push('Falta Nombre');
    if(!lead.phone || !/^\+?\d{6,15}$/.test(lead.phone)) errors.push('Falta Teléfono válido');
    if(!lead.service) errors.push('Falta Servicio');
    return errors;
  }
  function upsertLeadFromWhatsApp(text){
    const db = getDB();
    const lead = parseWhatsApp(text);
    const errors = validateLead(lead);
    if(errors.length) return {ok:false, errors, lead};

    let contact = db.contacts.find(c => c.phone === lead.phone);
    if(!contact){
      contact = { id: uid('c'), name: lead.name, phone: lead.phone, email: lead.email || '', company:'', address: lead.address || '', zone: lead.zone, source:'WhatsApp', createdAt: todayIso() };
      db.contacts.push(contact);
    }else{
      contact.name = lead.name || contact.name;
      contact.email = lead.email || contact.email;
      contact.address = lead.address || contact.address;
      contact.zone = lead.zone || contact.zone;
    }
    const service = {
      id: uid('s'), contactId: contact.id, type: lead.service, zone: lead.zone, duration: durationFromType(db, lead.service, lead.durationRaw),
      priority: lead.priority, status:'Pendiente', requestedDate: normalizeDateInput(lead.requestedDate), preferredWindow: lead.preferredWindow,
      notes: lead.notes || 'Alta creada desde WhatsApp.', createdAt: todayIso(), source:'WhatsApp'
    };
    db.services.push(service);
    db.logs.unshift({ts:new Date().toISOString(), type:'WhatsApp', text:`Creado contacto ${contact.name} y servicio ${service.type}.`});
    planAll(db, true);
    saveDB(db);
    return {ok:true, contact, service: db.services.find(s=>s.id===service.id), db};
  }
  function normalizeDateInput(raw){
    const x = String(raw||'').trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(x)) return x;
    const m = x.match(/(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?/);
    if(m){
      const d = String(m[1]).padStart(2,'0');
      const mo = String(m[2]).padStart(2,'0');
      const y = m[3] ? (m[3].length===2 ? '20'+m[3] : m[3]) : '2026';
      return `${y}-${mo}-${d}`;
    }
    return todayIso();
  }

  function candidateDaysFrom(startIso, horizon){
    const start = parseDate(startIso || todayIso());
    return Array.from({length:horizon},(_,i)=>addDays(start,i));
  }
  function findBestSlot(db, service, daySchedules){
    const startIso = service.requestedDate && service.requestedDate >= todayIso() ? service.requestedDate : todayIso();
    const z = zoneInfo(db, service.zone);
    const duration = Number(service.duration || 90);
    const travelBuffer = Math.max(15, Math.round(z.travel * .35));
    let best = null;
    for(const date of candidateDaysFrom(startIso, 28)){
      if(isBlocked(db,date)) continue;
      const dateIso = iso(date);
      const windows = windowsFor(db,date).filter(w => service.preferredWindow === 'tarde' ? minFromTime(w.start) >= 12*60 : minFromTime(w.end) <= 15*60 || minFromTime(w.start)<12*60);
      const fallbackWindows = windows.length ? windows : windowsFor(db,date);
      for(const win of fallbackWindows){
        const key = dateIso;
        if(!daySchedules[key]) daySchedules[key] = [];
        let cursor = minFromTime(win.start);
        const scheduled = daySchedules[key].filter(x=>x.start >= minFromTime(win.start) && x.end <= minFromTime(win.end)).sort((a,b)=>a.start-b.start);
        for(const item of scheduled){
          const prevZone = item.zone;
          const zonePenalty = prevZone && prevZone !== service.zone ? travelBuffer : 8;
          if(cursor + duration + zonePenalty <= item.start){ break; }
          cursor = Math.max(cursor, item.end + (prevZone === service.zone ? 8 : travelBuffer));
        }
        const end = cursor + duration;
        if(end <= minFromTime(win.end)){
          const sameZoneCount = scheduled.filter(x=>x.zone===service.zone).length;
          const dayDelay = Math.max(0, Math.round((date - parseDate(startIso))/(24*60*60*1000)));
          const preferredPenalty = (service.preferredWindow === 'tarde' && cursor < 12*60) || (service.preferredWindow === 'mañana' && cursor >= 12*60) ? 20 : 0;
          const score = dayDelay*100 + preferredPenalty - sameZoneCount*15 + Math.abs(cursor - (z.preferred==='mañana'?600:960))/20;
          const candidate = {date:dateIso,start:cursor,end,score,section:sectionName(cursor,z),route:`${z.road} · ${z.km} km base · ${z.travel} min estimados`, reason:reasonText(service,dateIso,cursor,z)};
          if(!best || candidate.score < best.score) best = candidate;
        }
      }
      if(best && best.score < 35) break;
    }
    return best;
  }
  function sectionName(startMin,z){
    if(startMin < 12*60) return z.section || 'Mañana';
    if(startMin < 15*60) return 'Mediodía técnico';
    return z.section && z.section.toLowerCase().includes('tarde') ? z.section : 'Tarde operativa';
  }
  function reasonText(service,dateIso,start,z){
    const req = service.requestedDate;
    const movedFriday = req && parseDate(req).getDay() === 5;
    const bits = [];
    if(movedFriday) bits.push('movido por viernes bloqueado');
    if(dateIso !== req && !movedFriday) bits.push('movido por disponibilidad');
    bits.push(`franja ${timeFromMin(start)}`);
    bits.push(`zona ${z.name}`);
    bits.push(`ruta ${z.road}`);
    return bits.join(' · ');
  }
  function planAll(db, persist){
    const pending = db.services.slice().sort((a,b)=>{
      const p = priorityScore(a.priority) - priorityScore(b.priority);
      if(p) return p;
      const d = String(a.requestedDate).localeCompare(String(b.requestedDate));
      if(d) return d;
      return String(a.zone).localeCompare(String(b.zone));
    });
    const daySchedules = {};
    pending.forEach(s=>{
      const slot = findBestSlot(db,s,daySchedules);
      if(slot){
        s.scheduledDate = slot.date;
        s.start = timeFromMin(slot.start);
        s.end = timeFromMin(slot.end);
        s.section = slot.section;
        s.route = slot.route;
        s.planningReason = slot.reason;
        s.status = s.status === 'Finalizado' ? 'Finalizado' : 'Planificado';
        const key = slot.date;
        daySchedules[key].push({id:s.id, start:slot.start, end:slot.end, zone:s.zone});
      }else{
        s.status = 'Sin hueco';
        s.planningReason = 'No hay capacidad en el horizonte de 28 días.';
      }
    });
    if(persist) db.logs.unshift({ts:new Date().toISOString(), type:'Planificador', text:'Servicios reorganizados. Viernes y domingo quedan sin servicios.'});
    return db;
  }

  function navActive(){
    const file = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav a').forEach(a=>{ if(a.getAttribute('href')===file) a.classList.add('active'); });
  }
  function renderLayoutMeta(){
    const meta = document.querySelector('[data-sync-status]');
    if(meta){ meta.textContent = 'Datos locales · localStorage · demo sin backend'; }
  }
  function renderKpis(){
    const db = getDB();
    const set = (id,val)=>{ const el=document.getElementById(id); if(el) el.textContent=val; };
    set('kpiContacts', db.contacts.length);
    set('kpiServices', db.services.length);
    set('kpiFriday', db.services.filter(s=>s.scheduledDate && parseDate(s.scheduledDate).getDay()===5).length);
    set('kpiPending', db.services.filter(s=>s.status!=='Finalizado').length);
    set('kpiRoutes', new Set(db.services.map(s=>s.zone)).size);
  }
  function pillStatus(status){
    const s = status || 'Pendiente';
    const cls = s==='Planificado'?'ok':(s==='Sin hueco'?'danger':(s==='Pendiente'?'warn':'dark'));
    return `<span class="pill ${cls}">${escapeHtml(s)}</span>`;
  }
  function escapeHtml(str){ return String(str ?? '').replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
  function fmtDate(str){
    if(!str) return '-';
    const d = parseDate(str);
    return `${DAY_SHORT[d.getDay()]} ${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;
  }
  function renderAgenda(limit=8){
    const db = getDB();
    const el = document.getElementById('agendaList'); if(!el) return;
    const items = db.services.filter(s=>s.scheduledDate).sort((a,b)=>(a.scheduledDate+a.start).localeCompare(b.scheduledDate+b.start)).slice(0,limit);
    if(!items.length){ el.innerHTML='<div class="empty">Sin servicios planificados.</div>'; return; }
    el.innerHTML = items.map(s=>{
      const c = contactById(db,s.contactId) || {};
      const z = zoneInfo(db,s.zone);
      return `<div class="timeline-item"><div class="timebox">${fmtDate(s.scheduledDate)}<br>${escapeHtml(s.start)}-${escapeHtml(s.end)}</div><div><strong>${escapeHtml(s.type)}</strong><br><span class="muted">${escapeHtml(c.name)} · ${escapeHtml(z.name)} · ${escapeHtml(s.section)}</span><br><span class="mini">${escapeHtml(s.route)}</span></div></div>`;
    }).join('');
  }
  function renderLogs(){
    const db = getDB();
    const el = document.getElementById('logList'); if(!el) return;
    el.innerHTML = db.logs.slice(0,6).map(l=>`<div class="notice"><strong>${escapeHtml(l.type)}</strong><br>${escapeHtml(l.text)}<br><span class="mini">${new Date(l.ts).toLocaleString()}</span></div>`).join('');
  }
  function renderContacts(){
    const db = getDB();
    const tbody = document.querySelector('#contactsTable tbody'); if(!tbody) return;
    const q = (document.getElementById('contactSearch')?.value || '').toLowerCase();
    const rows = db.contacts.filter(c => [c.name,c.phone,c.email,c.address,c.zone,c.source,c.company].join(' ').toLowerCase().includes(q));
    tbody.innerHTML = rows.map(c=>{
      const z = zoneInfo(db,c.zone);
      const count = db.services.filter(s=>s.contactId===c.id).length;
      return `<tr><td><strong>${escapeHtml(c.name)}</strong><br><span class="mini">${escapeHtml(c.company || 'Sin empresa')}</span></td><td>${escapeHtml(c.phone)}<br><span class="mini">${escapeHtml(c.email)}</span></td><td>${escapeHtml(c.address)}</td><td><span class="pill">${escapeHtml(z.name)}</span><br><span class="mini">${escapeHtml(z.road)}</span></td><td>${escapeHtml(c.source)}</td><td>${count}</td></tr>`;
    }).join('') || '<tr><td colspan="6" class="empty">Sin contactos.</td></tr>';
  }
  function renderServices(){
    const db = getDB();
    const tbody = document.querySelector('#servicesTable tbody'); if(!tbody) return;
    const filter = document.getElementById('serviceFilter')?.value || 'todos';
    const rows = db.services.filter(s => filter==='todos' || s.zone===filter).sort((a,b)=>(a.scheduledDate+a.start).localeCompare(b.scheduledDate+b.start));
    tbody.innerHTML = rows.map(s=>{
      const c = contactById(db,s.contactId) || {};
      const z = zoneInfo(db,s.zone);
      const friday = s.scheduledDate && parseDate(s.scheduledDate).getDay()===5;
      return `<tr><td><strong>${escapeHtml(s.type)}</strong><br>${pillStatus(s.status)} ${s.priority==='urgente'?'<span class="pill danger">Urgente</span>':''}</td><td>${escapeHtml(c.name)}<br><span class="mini">${escapeHtml(c.phone)}</span></td><td><span class="pill">${escapeHtml(z.name)}</span><br><span class="mini">${escapeHtml(s.route)}</span></td><td>${fmtDate(s.scheduledDate)}<br><span class="mini">${escapeHtml(s.start)}-${escapeHtml(s.end)} · ${s.duration} min</span></td><td>${escapeHtml(s.section)}</td><td class="${friday?'danger-text':''}">${escapeHtml(s.planningReason || '')}</td></tr>`;
    }).join('') || '<tr><td colspan="6" class="empty">Sin servicios.</td></tr>';
  }
  function renderCalendar(){
    const db = getDB();
    const wrap = document.getElementById('calendarGrid'); if(!wrap) return;
    const start = parseDate(document.getElementById('weekStart')?.value || todayIso());
    const monday = addDays(start, start.getDay()===0 ? 1 : 1-start.getDay());
    const days = [0,1,2,3,4,5].map(i=>addDays(monday,i));
    wrap.innerHTML = days.map(day=>{
      const dIso = iso(day);
      const services = db.services.filter(s=>s.scheduledDate===dIso).sort((a,b)=>String(a.start).localeCompare(String(b.start)));
      const friday = day.getDay()===5;
      return `<div class="day ${friday?'friday':''}"><div class="day-head">${WEEK_DAYS[day.getDay()]}<small>${dIso}${friday?' · LIBRE SIN SERVICIOS':''}</small></div>${friday?'<div class="notice danger" style="margin:10px">Bloqueado para liberar el viernes.</div>':''}${services.map(s=>{
        const c=contactById(db,s.contactId)||{}; const z=zoneInfo(db,s.zone);
        return `<div class="slot"><strong>${escapeHtml(s.start)} · ${escapeHtml(s.type)}</strong><div class="meta">${escapeHtml(c.name)}<br>${escapeHtml(z.name)} · ${escapeHtml(s.section)}<br>${escapeHtml(s.route)}</div></div>`;
      }).join('') || (!friday?'<div class="empty" style="margin:10px">Sin servicios asignados.</div>':'')}</div>`;
    }).join('');
  }
  function renderZones(){
    const db = getDB();
    const el = document.getElementById('zoneCards'); if(!el) return;
    el.innerHTML = Object.entries(db.settings.zones).map(([code,z])=>`<div class="zone-card"><div class="zone-code">${escapeHtml(code)}</div><strong>${escapeHtml(z.name)}</strong><div class="mini">${escapeHtml(z.road)}<br>${z.km} km · ${z.travel} min<br>Bloque: ${escapeHtml(z.section)}</div></div>`).join('');
  }
  function renderSettings(){
    const db = getDB();
    const el = document.getElementById('settingsSummary'); if(!el) return;
    const fridayBlocked = db.settings.blockedWeekdays.includes(5);
    el.innerHTML = `<div class="notice ${fridayBlocked?'ok':'danger'}"><strong>Viernes:</strong> ${fridayBlocked?'bloqueado para no hacer servicios':'no está bloqueado'}.</div><div class="notice"><strong>Base:</strong> ${escapeHtml(db.settings.base.address)}</div>`;
  }

  const sampleMessage = `Alta contratación WhatsApp
Nombre: Laura Martín
Teléfono: 600888999
Email: laura.martin@mail.com
Servicio: Mantenimiento mensual
Dirección: Calle Serrano 45, Madrid
Zona: Norte
Carretera: A-1
Duración: 90 minutos
Preferencia: mañana
Prioridad: alta
Fecha objetivo: 2026-05-15
Notas: viene de WhatsApp y pide confirmación rápida.`;

  function openWhatsAppModal(){
    const modal = document.getElementById('whatsappModal'); if(!modal) return;
    const area = document.getElementById('whatsappText');
    if(area && !area.value) area.value = sampleMessage;
    modal.style.display='flex';
  }
  function closeWhatsAppModal(){ const modal=document.getElementById('whatsappModal'); if(modal) modal.style.display='none'; }
  function simulateWhatsApp(){
    const area = document.getElementById('whatsappText');
    const result = document.getElementById('whatsappResult');
    const res = upsertLeadFromWhatsApp(area.value);
    if(!result) return;
    if(!res.ok){ result.className='notice danger status-line'; result.innerHTML='<strong>No se pudo crear.</strong><br>'+res.errors.map(escapeHtml).join('<br>'); return; }
    result.className='notice ok status-line';
    result.innerHTML = `<strong>Creado y planificado.</strong><br>Contacto: ${escapeHtml(res.contact.name)}<br>Servicio: ${escapeHtml(res.service.type)} · ${fmtDate(res.service.scheduledDate)} ${escapeHtml(res.service.start)}-${escapeHtml(res.service.end)}<br>${escapeHtml(res.service.planningReason)}`;
    renderAll();
  }
  function replan(){
    const db = getDB();
    planAll(db,true); saveDB(db); renderAll();
    const el=document.getElementById('serviceStatus'); if(el){ el.className='notice ok'; el.textContent='Calendario reorganizado. El viernes queda liberado.'; }
  }

  function bindCommon(){
    document.querySelectorAll('[data-action="reset-demo"]').forEach(b=>b.addEventListener('click', resetDemo));
    document.querySelectorAll('[data-action="open-whatsapp"]').forEach(b=>b.addEventListener('click', openWhatsAppModal));
    document.querySelectorAll('[data-action="close-whatsapp"]').forEach(b=>b.addEventListener('click', closeWhatsAppModal));
    document.querySelectorAll('[data-action="simulate-whatsapp"]').forEach(b=>b.addEventListener('click', simulateWhatsApp));
    document.querySelectorAll('[data-action="replan"]').forEach(b=>b.addEventListener('click', replan));
    const cSearch=document.getElementById('contactSearch'); if(cSearch) cSearch.addEventListener('input', renderContacts);
    const sFilter=document.getElementById('serviceFilter'); if(sFilter) sFilter.addEventListener('change', renderServices);
    const week=document.getElementById('weekStart'); if(week){ week.value=todayIso(); week.addEventListener('change', renderCalendar); }
  }
  function renderAll(){ renderKpis(); renderAgenda(); renderLogs(); renderContacts(); renderServices(); renderCalendar(); renderZones(); renderSettings(); }
  window.CRM = { getDB, resetDemo, replan, openWhatsAppModal, simulateWhatsApp, upsertLeadFromWhatsApp };
  document.addEventListener('DOMContentLoaded', ()=>{ navActive(); renderLayoutMeta(); bindCommon(); renderAll(); });
})();
