CRM LOCAL MULTIPÁGINA - WHATSAPP + SERVICIOS + CALENDARIO

Cómo usarlo:
1. Descomprime la carpeta.
2. Abre index.html en Chrome, Edge o Safari.
3. Pulsa “Simular WhatsApp”.
4. Pulsa “Crear contacto + servicio”.
5. Revisa Contactos, Servicios y Calendario.

Notas:
- No necesita servidor.
- No usa bases de datos externas.
- Guarda los datos en localStorage del navegador.
- El botón “Recargar demo” borra los datos locales y vuelve a cargar el CRM de ejemplo.
- El viernes está bloqueado para no asignar servicios.
- Las reglas están en app.js: horarios, zonas, carreteras, tiempos y duración por tipo de servicio.
