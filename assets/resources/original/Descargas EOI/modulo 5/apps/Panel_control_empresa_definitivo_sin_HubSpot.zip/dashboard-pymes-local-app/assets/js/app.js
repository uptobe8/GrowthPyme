(function(){
  "use strict";

  var STORAGE_KEY = "dashboard-pymes-local-v1";
  var state = loadState();

  function $(selector, parent){
    return (parent || document).querySelector(selector);
  }

  function $all(selector, parent){
    return Array.prototype.slice.call((parent || document).querySelectorAll(selector));
  }

  function safeNumber(value, fallback){
    var n = Number(value);
    return isFinite(n) ? n : (fallback || 0);
  }

  function clamp(value, min, max){
    return Math.max(min, Math.min(max, value));
  }

  function euro(value){
    return safeNumber(value).toLocaleString("es-ES", {maximumFractionDigits:0}) + " €";
  }

  function percent(value){
    return safeNumber(value).toLocaleString("es-ES", {maximumFractionDigits:0}) + "%";
  }

  function number(value){
    return safeNumber(value).toLocaleString("es-ES", {maximumFractionDigits:0});
  }

  function loadState(){
    try{
      var saved = localStorage.getItem(STORAGE_KEY);
      if(saved){
        return Object.assign({}, window.DEFAULT_STATE, JSON.parse(saved));
      }
    }catch(e){}
    return Object.assign({}, window.DEFAULT_STATE);
  }

  function saveState(){
    try{
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      toast("Datos guardados en este dispositivo");
    }catch(e){
      toast("No se pudo guardar en este visor. La app sigue funcionando.");
    }
  }

  function resetState(){
    state = Object.assign({}, window.DEFAULT_STATE);
    renderAll();
    toast("Datos de ejemplo restaurados");
  }

  function statusRevenue(actual, min, good){
    if(actual < min) return {color:"red", label:"Rojo", decision:"Captar más, subir ticket medio o reducir costes."};
    if(actual < good) return {color:"amber", label:"Ámbar", decision:"Reforzar ventas antes de cerrar el mes."};
    return {color:"green", label:"Verde", decision:"Mantener ritmo y valorar escalar."};
  }

  function statusByPercent(value, redMax, amberMax, highIsGood){
    var color;
    if(highIsGood){
      color = value < redMax ? "red" : (value < amberMax ? "amber" : "green");
    }else{
      color = value > amberMax ? "red" : (value > redMax ? "amber" : "green");
    }
    return color;
  }

  function buildCard(priority, title, purpose, body, status){
    return ''+
      '<article class="card '+(priority === 5 || priority === 6 ? 'wide' : 'third')+'">'+
        '<div class="card-head">'+
          '<div><h3 class="card-title">'+title+'</h3><p class="card-purpose">'+purpose+'</p></div>'+
          '<div class="priority">'+priority+'</div>'+
        '</div>'+
        body+
        '<div class="status-box '+status.color+'"><b>'+status.label+':</b> '+status.text+'</div>'+
      '</article>';
  }

  function renderScoreStrip(){
    var breakEven = state.costesFijos + state.costesVariables;
    var margenCaja = state.saldoCaja + state.cobrosPrevistos - state.pagosPrevistos;
    var ocupacion = state.horasDisponibles ? (state.horasVendidas / state.horasDisponibles) * 100 : 0;
    var costeCliente = state.clientesConseguidos ? state.inversionCampanas / state.clientesConseguidos : 0;

    $("#scoreStrip").innerHTML = ''+
      '<article class="score-card"><span>Facturación actual</span><strong>'+euro(state.facturacionActual)+'</strong></article>'+
      '<article class="score-card"><span>Punto de equilibrio</span><strong>'+euro(breakEven)+'</strong></article>'+
      '<article class="score-card"><span>Ocupación de agenda</span><strong>'+percent(ocupacion)+'</strong></article>'+
      '<article class="score-card"><span>Coste por cliente</span><strong>'+euro(costeCliente)+'</strong></article>';
  }

  function renderGauge(value, min, good, label){
    var ratio = good ? clamp(value / good, 0, 1.25) : 0;
    var deg = -70 + (clamp(ratio,0,1) * 140);
    return ''+
      '<div class="gauge" role="img" aria-label="'+label+'">'+
        '<div class="gauge-arc">'+
          '<div class="gauge-ring"></div>'+
          '<div class="gauge-hole"></div>'+
          '<div class="gauge-needle" style="transform:translateX(-50%) rotate('+deg+'deg)"></div>'+
        '</div>'+
        '<div class="gauge-value"><strong>'+euro(value)+'</strong><span>mínimo '+euro(min)+' · bueno '+euro(good)+'</span></div>'+
      '</div>';
  }

  function renderProgress(label, value, max, color){
    var pct = max ? clamp((value / max) * 100, 0, 100) : 0;
    return ''+
      '<div class="progress-block">'+
        '<div class="progress-label"><span>'+label+'</span><b>'+number(value)+' / '+number(max)+'</b></div>'+
        '<div class="track"><div class="fill '+(color || '')+'" style="width:'+pct+'%"></div></div>'+
      '</div>';
  }

  function renderMiniKpis(items){
    return '<div class="metric-row">'+items.map(function(item){
      return '<div class="mini-kpi"><span>'+item[0]+'</span><strong>'+item[1]+'</strong></div>';
    }).join("")+'</div>';
  }

  function renderDashboard(){
    var cards = [];
    var revenueStatus = statusRevenue(state.facturacionActual, state.objetivoMinimo, state.objetivoBueno);

    cards.push(buildCard(
      1,
      "Cuentakilómetros de facturación objetivo",
      "Saber si estás lejos, cerca o por encima del objetivo.",
      renderGauge(state.facturacionActual, state.objetivoMinimo, state.objetivoBueno, "Cuentakilómetros de facturación")+
      renderMiniKpis([["Actual",euro(state.facturacionActual)],["Mínimo",euro(state.objetivoMinimo)],["Bueno",euro(state.objetivoBueno)]]),
      {color:revenueStatus.color, label:revenueStatus.label, text:revenueStatus.decision}
    ));

    var breakEven = state.costesFijos + state.costesVariables;
    var breakColor = statusByPercent(state.facturacionActual / Math.max(breakEven,1) * 100, 80, 100, true);
    cards.push(buildCard(
      2,
      "Punto de equilibrio mensual",
      "Saber cuánto hay que facturar para cubrir costes.",
      renderProgress("Ingresos frente a costes", state.facturacionActual, breakEven, breakColor)+
      renderMiniKpis([["Costes fijos",euro(state.costesFijos)],["Variables",euro(state.costesVariables)],["Faltan",euro(Math.max(0, breakEven-state.facturacionActual))]]),
      {color:breakColor, label:labelFromColor(breakColor), text: breakColor === "green" ? "El negocio cubre costes. Revisar beneficio real." : "No asumir más costes hasta cubrir el mínimo mensual."}
    ));

    var neededClients = Math.ceil(state.costeContratacion / Math.max(state.ticketMedio,1));
    var currentExtra = Math.max(0, Math.floor((state.facturacionActual - breakEven) / Math.max(state.ticketMedio,1)));
    var hireColor = currentExtra >= neededClients ? "green" : (currentExtra >= neededClients*0.6 ? "amber" : "red");
    cards.push(buildCard(
      3,
      "Clientes necesarios para contratar",
      "Saber cuántos clientes faltan para contratar sin riesgo.",
      '<div class="dual"><div class="big-box"><strong>'+number(neededClients)+'</strong><span>clientes necesarios</span></div><div class="big-box"><strong>'+euro(state.costeContratacion)+'</strong><span>coste mensual</span></div></div>'+
      renderProgress("Clientes extra cubiertos", currentExtra, neededClients, hireColor),
      {color:hireColor, label:labelFromColor(hireColor), text: hireColor === "green" ? "La contratación empieza a ser defendible si la caja acompaña." : "Faltan "+number(Math.max(0,neededClients-currentExtra))+" clientes para cubrir la contratación."}
    ));

    var expectedNow = state.facturacionEsperadaMes * (state.diasTranscurridos / Math.max(state.diasMes,1));
    var pace = expectedNow ? (state.facturacionActual / expectedNow) * 100 : 0;
    var paceColor = statusByPercent(pace, 75, 100, true);
    cards.push(buildCard(
      4,
      "Facturación real vs objetivo",
      "Ver si el negocio va por delante o por detrás del mes.",
      renderProgress("Ritmo del mes", state.facturacionActual, expectedNow, paceColor)+
      renderMiniKpis([["Esperado hoy",euro(expectedNow)],["Real",euro(state.facturacionActual)],["Desvío",euro(state.facturacionActual-expectedNow)]]),
      {color:paceColor, label:labelFromColor(paceColor), text: paceColor === "green" ? "El mes va por encima o en línea con el ritmo previsto." : "Hay que reforzar ventas antes de final de mes."}
    ));

    cards.push(buildCard(
      5,
      "Margen por servicio/producto",
      "Detectar qué servicios merece la pena potenciar o eliminar.",
      renderServices(),
      {color:"amber", label:"Lectura", text:"Potenciar servicios con margen alto; subir precio o rediseñar los de margen bajo."}
    ));

    var funnelBody = renderFunnel();
    var convBudgetSale = state.presupuestos ? (state.ventas / state.presupuestos) * 100 : 0;
    var funnelColor = statusByPercent(convBudgetSale, 25, 45, true);
    cards.push(buildCard(
      6,
      "Embudo de ventas",
      "Ver dónde se pierden contactos: visita, llamada, presupuesto y venta.",
      funnelBody,
      {color:funnelColor, label:labelFromColor(funnelColor), text:"Revisar la etapa con mayor caída antes de aumentar inversión."}
    ));

    var cpa = state.clientesConseguidos ? state.inversionCampanas / state.clientesConseguidos : 0;
    var cpaLimit = state.ticketMedio * 0.30;
    var cpaColor = cpa <= cpaLimit ? "green" : (cpa <= cpaLimit*1.35 ? "amber" : "red");
    cards.push(buildCard(
      7,
      "Coste por cliente conseguido",
      "Saber si merece la pena seguir invirtiendo.",
      renderGauge(cpa, cpaLimit*0.8, cpaLimit, "Coste por cliente conseguido")+
      renderMiniKpis([["Inversión",euro(state.inversionCampanas)],["Clientes",number(state.clientesConseguidos)],["Máximo recomendado",euro(cpaLimit)]]),
      {color:cpaColor, label:labelFromColor(cpaColor), text: cpaColor === "green" ? "La campaña puede escalar con control." : "Revisar campaña, oferta o conversión antes de invertir más."}
    ));

    var occupancy = state.horasDisponibles ? (state.horasVendidas / state.horasDisponibles) * 100 : 0;
    var occColor = occupancy < 60 ? "red" : (occupancy < 85 ? "amber" : "green");
    cards.push(buildCard(
      8,
      "Ocupación de agenda/capacidad",
      "Saber si falta demanda o falta capacidad.",
      renderCalendar(occupancy)+
      renderMiniKpis([["Horas vendidas",number(state.horasVendidas)+" h"],["Disponibles",number(state.horasDisponibles)+" h"],["Ocupación",percent(occupancy)]]),
      {color:occColor, label:labelFromColor(occColor), text: occupancy >= 85 ? "Valorar subir precio, ampliar horarios o contratar." : "Cubrir huecos antes de ampliar capacidad."}
    ));

    var recTotal = state.clientesNuevos + state.clientesRecurrentes;
    var newPct = recTotal ? state.clientesNuevos / recTotal * 100 : 0;
    var recPct = recTotal ? state.clientesRecurrentes / recTotal * 100 : 0;
    var recColor = recPct >= 55 ? "green" : (recPct >= 35 ? "amber" : "red");
    cards.push(buildCard(
      9,
      "Clientes nuevos vs recurrentes",
      "Saber si el negocio depende demasiado de captar siempre.",
      '<div class="dual"><div class="big-box"><strong>'+percent(newPct)+'</strong><span>nuevos</span></div><div class="big-box"><strong>'+percent(recPct)+'</strong><span>recurrentes</span></div></div>'+
      renderProgress("Base recurrente", recPct, 100, recColor),
      {color:recColor, label:labelFromColor(recColor), text: recColor === "green" ? "Buena base para venta cruzada y fidelización." : "Activar recuperación de clientes e incentivos de repetición."}
    ));

    var cajaFinal = state.saldoCaja + state.cobrosPrevistos - state.pagosPrevistos;
    var cashColor = cajaFinal < 0 ? "red" : (cajaFinal < state.pagosPrevistos*0.15 ? "amber" : "green");
    cards.push(buildCard(
      10,
      "Previsión de caja",
      "Saber si habrá dinero suficiente para pagos próximos.",
      renderCash(cajaFinal)+
      renderMiniKpis([["Saldo inicial",euro(state.saldoCaja)],["Cobros",euro(state.cobrosPrevistos)],["Pagos",euro(state.pagosPrevistos)]]),
      {color:cashColor, label:labelFromColor(cashColor), text: cashColor === "green" ? "Hay colchón para pagos próximos." : "Acelerar cobros, aplazar gasto o reducir salidas."}
    ));

    $("#dashboardGrid").innerHTML = cards.join("");
  }

  function labelFromColor(color){
    if(color === "red") return "Rojo";
    if(color === "amber") return "Ámbar";
    return "Verde";
  }

  function renderServices(){
    var rows = window.SERVICES.map(function(s){
      var margin = s.revenue ? ((s.revenue - s.cost) / s.revenue) * 100 : 0;
      var color = margin >= 55 ? "green" : (margin >= 35 ? "amber" : "red");
      return '<div class="service-row">'+
        '<span class="service-name">'+s.name+'</span>'+
        '<div class="service-bar"><div class="service-fill '+color+'" style="width:'+clamp(margin,0,100)+'%"></div></div>'+
        '<b>'+percent(margin)+'</b>'+
      '</div>';
    }).join("");
    return '<div class="service-list">'+rows+'</div>';
  }

  function renderFunnel(){
    var stages = [
      ["Visitas", state.visitasWeb],
      ["Contactos", state.contactos],
      ["Llamadas", state.llamadas],
      ["Presupuestos", state.presupuestos],
      ["Ventas", state.ventas]
    ];
    var max = Math.max(1, stages[0][1]);
    var html = '<div class="funnel">';
    for(var i=0;i<stages.length;i++){
      var width = clamp((stages[i][1]/max)*100, 18, 100);
      var shade = 18 + (i*15);
      html += '<div class="funnel-step" style="width:'+width+'%;background:hsl(222,35%,'+shade+'%)">'+stages[i][0]+': '+number(stages[i][1])+'</div>';
    }
    html += '</div>';
    return html;
  }

  function renderCalendar(occupancy){
    var html = '<div class="calendar-grid">';
    for(var i=0;i<28;i++){
      var variance = ((i*17)%37) - 18;
      var dayValue = clamp(occupancy + variance, 0, 100);
      var color = dayValue < 60 ? "red" : (dayValue < 85 ? "amber" : "green");
      html += '<div class="day '+color+'" title="'+percent(dayValue)+'"></div>';
    }
    html += '</div>';
    return html;
  }

  function renderCash(cajaFinal){
    var values = [
      state.saldoCaja,
      state.saldoCaja + state.cobrosPrevistos*0.2 - state.pagosPrevistos*0.15,
      state.saldoCaja + state.cobrosPrevistos*0.45 - state.pagosPrevistos*0.38,
      state.saldoCaja + state.cobrosPrevistos*0.6 - state.pagosPrevistos*0.72,
      state.saldoCaja + state.cobrosPrevistos*0.82 - state.pagosPrevistos*0.9,
      cajaFinal
    ];
    var max = Math.max.apply(null, values.map(function(v){return Math.abs(v);}).concat([1]));
    var html = '<div class="cash-bars">';
    values.forEach(function(v){
      var color = v < 0 ? "red" : (v < max*0.25 ? "amber" : "green");
      var height = clamp(Math.abs(v)/max*120, 16, 120);
      html += '<div class="cash-bar '+color+'" style="height:'+height+'px"></div>';
    });
    html += '</div><div class="axis"><span>S1</span><span>S2</span><span>S3</span><span>S4</span><span>S5</span><span>S6</span></div>'+
            '<div class="gauge-value"><strong>'+euro(cajaFinal)+'</strong><span>saldo previsto final</span></div>';
    return html;
  }

  function renderForm(){
    var html = window.FORM_FIELDS.map(function(field){
      return '<div class="field">'+
        '<label for="'+field.key+'">'+field.label+'</label>'+
        '<input id="'+field.key+'" name="'+field.key+'" type="number" inputmode="decimal" step="1" value="'+state[field.key]+'">'+
        '<small>'+field.help+' · '+field.suffix+'</small>'+
      '</div>';
    }).join("");
    $("#dataForm").innerHTML = html;

    $all("#dataForm input").forEach(function(input){
      input.addEventListener("input", function(){
        state[input.name] = safeNumber(input.value, 0);
        renderScoreStrip();
        renderDashboard();
      });
    });
  }

  function renderCatalog(){
    var query = ($("#metricSearch") && $("#metricSearch").value || "").toLowerCase().trim();
    var list = window.ALL_METRICS.filter(function(item){
      return !query || (item[0]+" "+item[1]+" "+item[2]).toLowerCase().indexOf(query) !== -1;
    });

    $("#catalogGrid").innerHTML = list.map(function(item, index){
      return '<article class="catalog-card">'+
        '<span class="badge">'+item[2]+'</span>'+
        '<h3>'+item[0]+'</h3>'+
        '<p>'+item[1]+'</p>'+
        '<span class="badge">Decisión clara</span>'+
      '</article>';
    }).join("");
  }

  function bindTabs(){
    $all(".tab").forEach(function(btn){
      btn.addEventListener("click", function(){
        var id = btn.getAttribute("data-tab");
        $all(".tab").forEach(function(b){ b.classList.remove("is-active"); });
        $all(".tab-panel").forEach(function(panel){ panel.classList.remove("is-active"); });
        btn.classList.add("is-active");
        $("#"+id).classList.add("is-active");
        window.scrollTo({top:0, behavior:"smooth"});
      });
    });
  }

  function toast(message){
    var existing = $(".toast");
    if(existing) existing.remove();
    var node = document.createElement("div");
    node.className = "toast";
    node.textContent = message;
    node.style.cssText = "position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);background:#0f172a;color:white;padding:12px 16px;border-radius:999px;z-index:999;box-shadow:0 12px 32px rgba(15,23,42,.22);font-weight:800;font-size:13px;max-width:calc(100% - 28px);text-align:center;";
    document.body.appendChild(node);
    setTimeout(function(){ if(node && node.parentNode) node.parentNode.removeChild(node); }, 2200);
  }

  function renderAll(){
    renderScoreStrip();
    renderDashboard();
    renderForm();
    renderCatalog();
  }

  function init(){
    bindTabs();
    renderAll();

    $("#saveDataBtn").addEventListener("click", saveState);
    $("#resetDataBtn").addEventListener("click", resetState);
    $("#metricSearch").addEventListener("input", renderCatalog);

    if("serviceWorker" in navigator && location.protocol.indexOf("http") === 0){
      navigator.serviceWorker.register("service-worker.js").catch(function(){});
    }
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", init);
  }else{
    init();
  }
})();
