# Dashboard Decisiones Pyme

App local en HTML, CSS y JavaScript para explicar métricas empresariales con la lógica:

Dato → Umbral → Color → Decisión

## Cómo abrirla

1. Descomprime la carpeta `dashboard-pymes-local-app`.
2. Abre `index.html`.
3. Funciona sin internet y sin instalar librerías.

## Compatibilidad

- Ordenador: abrir `index.html` en Chrome, Safari, Edge o Firefox.
- Android: abrir `index.html` desde Archivos, Chrome o navegador compatible.
- iPhone/iPad: descomprimir en Archivos y abrir `index.html`. Si la vista previa no ejecuta JavaScript, usar compartir/abrir con Safari.

## Archivos principales

- `index.html`: dashboard principal.
- `cliente.html`: área privada local del cliente.
- `integraciones.html`: centro de conexión para Google Calendar y Gmail.
- `assets/css/styles.css`: diseño responsive.
- `assets/js/data.js`: datos base del dashboard.
- `assets/js/app.js`: cálculos y navegación del dashboard.
- `assets/js/client-area.js`: presupuestos, facturas, avisos y calendario local.
- `assets/js/integrations.js`: capa API para Calendar y Gmail.
- `assets/js/integrations-page.js`: interfaz de pruebas API.
- `api-config.template.json`: plantilla de configuración sin claves reales.

## Integraciones activas

- Google Calendar API: crear eventos de vencimiento de presupuestos con avisos a 10 días, 5 días y 24 horas.
- Gmail API: enviar emails de aviso de aceptación de presupuestos.

## Notas

La app no envía datos por sí sola. Para llamadas API reales necesitas tus credenciales OAuth/autorizadas o un endpoint puente propio.

No se incluyen claves, secretos ni tokens permanentes dentro del ZIP.

En local se mantiene:

- Dashboard.
- Área privada de cliente.
- Simulador de presupuestos.
- Facturas.
- Calendario visual.
- Exportación `.ics`.
- Pruebas de Google Calendar.
- Pruebas de Gmail.

La integración de CRM externa queda eliminada en esta versión.
