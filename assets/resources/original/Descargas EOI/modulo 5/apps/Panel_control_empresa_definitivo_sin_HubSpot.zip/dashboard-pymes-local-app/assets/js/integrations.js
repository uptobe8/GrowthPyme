(function(){
  "use strict";

  var CONFIG_KEY = "dashboard-pymes-integrations-v1";
  var LOG_KEY = "dashboard-pymes-integrations-log-v1";

  var API_CATALOG = [
    {
      id:"google-calendar",
      title:"Google Calendar API",
      use:"Crear eventos de vencimiento de presupuestos y recordatorios a 10 días, 5 días y 24 horas.",
      scopes:"https://www.googleapis.com/auth/calendar.events",
      endpoint:"POST https://www.googleapis.com/calendar/v3/calendars/{calendarId}/events",
      freeNote:"API pública de Google. Normalmente se puede usar con cuota gratuita, sujeta a límites y configuración OAuth."
    },
    {
      id:"gmail",
      title:"Gmail API",
      use:"Enviar emails de aviso de aceptación de presupuesto al cliente.",
      scopes:"https://www.googleapis.com/auth/gmail.send",
      endpoint:"POST https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
      freeNote:"API pública de Google. Requiere autorización del usuario de Gmail y consentimiento OAuth."
    }
  ];

  function normalizeConfig(config){
    config = config || {};
    return {
      googleCalendarId: config.googleCalendarId || "primary",
      googleAccessToken: config.googleAccessToken || "",
      gmailRecipient: config.gmailRecipient || "",
      proxyBaseUrl: config.proxyBaseUrl || ""
    };
  }

  function getConfig(){
    try{
      return normalizeConfig(JSON.parse(localStorage.getItem(CONFIG_KEY) || "{}"));
    }catch(e){
      return normalizeConfig({});
    }
  }

  function saveConfig(config){
    localStorage.setItem(CONFIG_KEY, JSON.stringify(normalizeConfig(Object.assign({}, getConfig(), config || {}))));
    addLog("Configuración guardada localmente.", "config");
  }

  function clearConfig(){
    localStorage.removeItem(CONFIG_KEY);
    addLog("Configuración borrada.", "config");
  }

  function addLog(message, type){
    var logs = getLogs();
    logs.unshift({message:message, type:type || "info", at:new Date().toISOString()});
    localStorage.setItem(LOG_KEY, JSON.stringify(logs.slice(0,30)));
  }

  function getLogs(){
    try{
      return JSON.parse(localStorage.getItem(LOG_KEY) || "[]");
    }catch(e){
      return [];
    }
  }

  function escapeHtml(value){
    return String(value == null ? "" : value).replace(/[&<>'"]/g, function(ch){
      return {"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch];
    });
  }

  function euro(value){
    return Number(value || 0).toLocaleString("es-ES", {maximumFractionDigits:0}) + " €";
  }

  function proxyUrl(path){
    var base = (getConfig().proxyBaseUrl || "").replace(/\/+$/, "");
    return base ? base + path : "";
  }

  function toDateOnly(date){
    var d = new Date(date);
    return d.toISOString().slice(0,10);
  }

  function addDays(date, days){
    var d = new Date(date);
    d.setDate(d.getDate()+days);
    return d;
  }

  function quoteToCalendarEvent(quote, client){
    var due = quote && quote.dueAt ? quote.dueAt : toDateOnly(addDays(new Date(), 15));
    var next = toDateOnly(addDays(due, 1));
    var title = quote && quote.id ? "Vence presupuesto " + quote.id : "Vence presupuesto";
    var description = "Aviso de aceptación de presupuesto. Cliente: " + ((client && client.name) || "Cliente") + ". Importe: " + euro(quote && quote.amount);

    return {
      summary:title,
      description:description,
      start:{date:due},
      end:{date:next},
      reminders:{
        useDefault:false,
        overrides:[
          {method:"popup", minutes:14400},
          {method:"popup", minutes:7200},
          {method:"popup", minutes:1440}
        ]
      }
    };
  }

  function base64Url(str){
    var utf8 = unescape(encodeURIComponent(str));
    return btoa(utf8).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
  }

  async function createGoogleCalendarQuoteEvent(quote, client){
    var config = getConfig();
    var payload = quoteToCalendarEvent(quote, client);
    var calendarId = encodeURIComponent(config.googleCalendarId || "primary");
    var proxy = proxyUrl("/calendar/quote-event");

    if(proxy){
      var proxyRes = await fetch(proxy, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          quote:quote,
          client:client,
          calendarId:config.googleCalendarId || "primary",
          event:payload
        })
      });
      if(!proxyRes.ok){
        addLog("Error endpoint puente Calendar.", "calendar");
        return {ok:false, message:"El endpoint puente de Calendar devolvió error."};
      }
      addLog("Evento enviado al endpoint puente de Calendar para "+((quote && quote.id) || "presupuesto demo")+".", "calendar");
      return {ok:true, message:"Evento enviado al endpoint puente de Calendar."};
    }

    if(!config.googleAccessToken){
      addLog("Google Calendar no ejecutado: falta access token temporal.", "calendar");
      return {ok:false, message:"Falta Google OAuth access token temporal. Configúralo en Integraciones API."};
    }

    var res = await fetch("https://www.googleapis.com/calendar/v3/calendars/"+calendarId+"/events", {
      method:"POST",
      headers:{
        "Authorization":"Bearer "+config.googleAccessToken,
        "Content-Type":"application/json"
      },
      body:JSON.stringify(payload)
    });

    if(!res.ok){
      var txt = await res.text();
      addLog("Error Google Calendar: "+txt.slice(0,160), "calendar");
      return {ok:false, message:"Google Calendar devolvió error. Revisa token, permisos y Calendar ID."};
    }

    addLog("Evento creado en Google Calendar para "+((quote && quote.id) || "presupuesto demo")+".", "calendar");
    return {ok:true, message:"Evento creado en Google Calendar."};
  }

  async function sendGmailQuoteReminder(quote, client){
    var config = getConfig();
    var to = config.gmailRecipient || (client && client.email) || "";
    var subject = "Recordatorio: presupuesto pendiente de aceptación";
    var body = "Hola,\n\nTe recordamos que el presupuesto " + ((quote && quote.id) || "") + " vence el " + ((quote && quote.dueAt) || "próximamente") + ".\n\nImporte: " + euro(quote && quote.amount) + "\n\nGracias.";

    var proxy = proxyUrl("/gmail/quote-reminder");
    if(proxy){
      var proxyRes = await fetch(proxy, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({quote:quote, client:client, to:to, subject:subject, body:body})
      });
      if(!proxyRes.ok){
        addLog("Error endpoint puente Gmail.", "gmail");
        return {ok:false, message:"El endpoint puente de Gmail devolvió error."};
      }
      addLog("Aviso enviado al endpoint puente Gmail para "+((quote && quote.id) || "presupuesto demo")+".", "gmail");
      return {ok:true, message:"Aviso enviado al endpoint puente Gmail."};
    }

    if(!config.googleAccessToken){
      var gmailCompose = "https://mail.google.com/mail/?view=cm&fs=1&to="+encodeURIComponent(to)+"&su="+encodeURIComponent(subject)+"&body="+encodeURIComponent(body);
      addLog("Gmail API no ejecutado: falta access token. Abriendo composición Gmail como fallback.", "gmail");
      if(typeof window !== "undefined") window.open(gmailCompose, "_blank");
      return {ok:false, message:"Falta token Gmail API. He abierto Gmail en modo composición si el navegador lo permite."};
    }

    if(!to){
      return {ok:false, message:"Falta email destino para enviar el aviso."};
    }

    var raw = base64Url("To: "+to+"\r\nSubject: "+subject+"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n"+body);
    var res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method:"POST",
      headers:{
        "Authorization":"Bearer "+config.googleAccessToken,
        "Content-Type":"application/json"
      },
      body:JSON.stringify({raw:raw})
    });

    if(!res.ok){
      var txt = await res.text();
      addLog("Error Gmail API: "+txt.slice(0,160), "gmail");
      return {ok:false, message:"Gmail API devolvió error. Revisa token y scope gmail.send."};
    }

    addLog("Email enviado con Gmail API para "+((quote && quote.id) || "presupuesto demo")+".", "gmail");
    return {ok:true, message:"Aviso enviado por Gmail API."};
  }

  function testQuote(){
    var now = new Date();
    return {
      id:"PRE-DEMO-API",
      title:"Presupuesto demo API",
      issuedAt:toDateOnly(now),
      dueAt:toDateOnly(addDays(now, 15)),
      amount:2450,
      status:"pending"
    };
  }

  window.CompanyIntegrations = {
    apiCatalog:API_CATALOG,
    getConfig:getConfig,
    saveConfig:saveConfig,
    clearConfig:clearConfig,
    getLogs:getLogs,
    addLog:addLog,
    escapeHtml:escapeHtml,
    quoteToCalendarEvent:quoteToCalendarEvent,
    createGoogleCalendarQuoteEvent:createGoogleCalendarQuoteEvent,
    sendGmailQuoteReminder:sendGmailQuoteReminder,
    testQuote:testQuote
  };
})();
