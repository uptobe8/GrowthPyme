var CACHE_NAME = "dashboard-pymes-local-v1";
var ASSETS = [
  "./",
  "./index.html",
  "./cliente.html",
  "./integraciones.html",
  "./assets/css/styles.css",
  "./assets/js/data.js",
  "./assets/js/app.js",
  "./assets/js/client-area.js",
  "./assets/js/integrations.js",
  "./assets/js/integrations-page.js",
  "./assets/icons/icon.svg",
  "./manifest.webmanifest"
];

self.addEventListener("install", function(event){
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache){
      return cache.addAll(ASSETS);
    })
  );
});

self.addEventListener("fetch", function(event){
  event.respondWith(
    caches.match(event.request).then(function(response){
      return response || fetch(event.request);
    })
  );
});
