(function(){
  "use strict";

  var STORAGE_KEY = "dashboard-pymes-client-area-v1";
  var selectedQuoteId = null;

  function $(selector, parent){
    return (parent || document).querySelector(selector);
  }

  function $all(selector, parent){
    return Array.prototype.slice.call((parent || document).querySelectorAll(selector));
  }

  function today(){
    var d = new Date();
    d.setHours(0,0,0,0);
    return d;
  }

  function addDays(date, days){
    var d = new Date(date);
    d.setDate(d.getDate() + days);
    return d;
  }

  function toISODate(date){
    return new Date(date).toISOString().slice(0,10);
  }

  function fromISODate(value){
    var parts = String(value).split("-");
    return new Date(Number(parts[0]), Number(parts[1])-1, Number(parts[2]));
  }

  function formatDate(value){
    return fromISODate(value).toLocaleDateString("es-ES", {day:"2-digit", month:"short", year:"numeric"});
  }

  function euro(value){
    return Number(value || 0).toLocaleString("es-ES", {maximumFractionDigits:0}) + " €";
  }

  function uid(prefix){
    return prefix + "-" + Math.random().toString(16).slice(2,6).toUpperCase() + "-" + Date.now().toString().slice(-4);
  }

  function defaultState(){
    var base = today();
    return {
      client:{
        name:"Cliente Demo SL",
        email:"cliente@demo.local",
        contact:"Dirección financiera"
      },
      quotes:[
        {
          id:"PRE-2026-001",
          title:"Implantación dashboard de analítica",
          issuedAt:toISODate(addDays(base,-5)),
          dueAt:toISODate(addDays(base,15)),
          amount:2450,
          status:"pending",
          services:[
            ["Configuración dashboard", 1, 1200],
            ["Plantillas de métricas", 1, 850],
            ["Formación equipo", 1, 400]
          ]
        }
      ],
      invoices:[
        {
          id:"FAC-2026-001",
          title:"Mantenimiento mensual",
          issuedAt:toISODate(addDays(base,-20)),
          dueAt:toISODate(addDays(base,10)),
          amount:490,
          status:"paid",
          services:[
            ["Soporte y mantenimiento", 1, 490]
          ]
        }
      ]
    };
  }

  function loadState(){
    try{
      var saved = localStorage.getItem(STORAGE_KEY);
      if(saved) return JSON.parse(saved);
    }catch(e){}
    return defaultState();
  }

  var state = loadState();

  function saveState(){
    try{
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }catch(e){}
  }

  function statusLabel(status){
    var map = {
      pending:"Pendiente",
      accepted:"Aceptado",
      expired:"Vencido",
      paid:"Pagada",
      unpaid:"Pendiente pago"
    };
    return map[status] || status;
  }

  function quoteStatus(quote){
    if(quote.status === "accepted") return "accepted";
    var due = fromISODate(quote.dueAt);
    if(due < today()) return "expired";
    return "pending";
  }

  function getActiveQuote(){
    if(!selectedQuoteId && state.quotes.length) selectedQuoteId = state.quotes[0].id;
    return state.quotes.find(function(q){ return q.id === selectedQuoteId; }) || state.quotes[0] || null;
  }

  function remindersForQuote(quote){
    if(!quote) return [];
    var due = fromISODate(quote.dueAt);
    return [
      {label:"10 días antes", type:"Seguimiento preventivo", date:toISODate(addDays(due,-10)), offset:10},
      {label:"5 días antes", type:"Segundo aviso comercial", date:toISODate(addDays(due,-5)), offset:5},
      {label:"24 horas antes", type:"Aviso urgente", date:toISODate(addDays(due,-1)), offset:1},
      {label:"Vencimiento", type:"Fecha límite de aceptación", date:quote.dueAt, offset:0}
    ];
  }

  function renderStatus(){
    var pending = state.quotes.filter(function(q){ return quoteStatus(q) === "pending"; }).length;
    var accepted = state.quotes.filter(function(q){ return quoteStatus(q) === "accepted"; }).length;
    var totalQuotes = state.quotes.reduce(function(sum,q){ return sum + Number(q.amount || 0); },0);
    var unpaid = state.invoices.filter(function(i){ return i.status === "unpaid"; }).length;

    $("#clientStatusGrid").innerHTML = ""+
      '<article><span>Presupuestos pendientes</span><strong>'+pending+'</strong></article>'+
      '<article><span>Presupuestos aceptados</span><strong>'+accepted+'</strong></article>'+
      '<article><span>Valor presupuestado</span><strong>'+euro(totalQuotes)+'</strong></article>'+
      '<article><span>Facturas pendientes</span><strong>'+unpaid+'</strong></article>';
  }

  function renderQuotes(){
    var el = $("#quotesList");
    if(!state.quotes.length){
      el.innerHTML = '<div class="empty-state">Todavía no hay presupuestos. Usa el botón de simulación.</div>';
      return;
    }

    el.innerHTML = state.quotes.map(function(q){
      var st = quoteStatus(q);
      var active = q.id === selectedQuoteId ? " · seleccionado" : "";
      return '<article class="doc-card">'+
        '<div class="doc-top">'+
          '<div>'+
            '<h4 class="doc-title">'+q.title+'</h4>'+
            '<p class="doc-meta">'+q.id+' · Emitido '+formatDate(q.issuedAt)+' · Vence '+formatDate(q.dueAt)+active+'</p>'+
            '<span class="status-pill '+st+'">'+statusLabel(st)+'</span>'+
          '</div>'+
          '<span class="doc-amount">'+euro(q.amount)+'</span>'+
        '</div>'+
        '<div class="doc-actions">'+
          '<button class="tiny-btn" data-action="select" data-id="'+q.id+'" type="button">Seleccionar</button>'+
          '<button class="tiny-btn" data-action="view-quote" data-id="'+q.id+'" type="button">Visualizar</button>'+
          (st === "pending" ? '<button class="tiny-btn primary" data-action="accept" data-id="'+q.id+'" type="button">Aceptar y generar factura</button>' : '')+
          (st === "pending" ? '<button class="tiny-btn danger" data-action="expire" data-id="'+q.id+'" type="button">Simular vencido</button>' : '')+
        '</div>'+
      '</article>';
    }).join("");

    bindDocumentActions(el);
  }

  function renderInvoices(){
    var el = $("#invoicesList");
    if(!state.invoices.length){
      el.innerHTML = '<div class="empty-state">Todavía no hay facturas. Acepta un presupuesto para crear una.</div>';
      return;
    }

    el.innerHTML = state.invoices.map(function(inv){
      return '<article class="doc-card">'+
        '<div class="doc-top">'+
          '<div>'+
            '<h4 class="doc-title">'+inv.title+'</h4>'+
            '<p class="doc-meta">'+inv.id+' · Emitida '+formatDate(inv.issuedAt)+' · Vence '+formatDate(inv.dueAt)+'</p>'+
            '<span class="status-pill '+inv.status+'">'+statusLabel(inv.status)+'</span>'+
          '</div>'+
          '<span class="doc-amount">'+euro(inv.amount)+'</span>'+
        '</div>'+
        '<div class="doc-actions">'+
          '<button class="tiny-btn" data-action="view-invoice" data-id="'+inv.id+'" type="button">Visualizar</button>'+
          (inv.status === "unpaid" ? '<button class="tiny-btn primary" data-action="pay" data-id="'+inv.id+'" type="button">Simular pagada</button>' : '')+
        '</div>'+
      '</article>';
    }).join("");

    bindDocumentActions(el);
  }

  function bindDocumentActions(parent){
    $all("[data-action]", parent).forEach(function(btn){
      btn.addEventListener("click", function(){
        var action = btn.getAttribute("data-action");
        var id = btn.getAttribute("data-id");

        if(action === "select"){
          selectedQuoteId = id;
          renderAll();
        }
        if(action === "view-quote") previewQuote(id);
        if(action === "view-invoice") previewInvoice(id);
        if(action === "accept") acceptQuote(id);
        if(action === "expire") expireQuote(id);
        if(action === "pay") payInvoice(id);
      });
    });
  }

  function renderTimeline(){
    var quote = getActiveQuote();
    var el = $("#reminderTimeline");
    if(!quote){
      el.innerHTML = '<div class="empty-state">Selecciona o crea un presupuesto para ver sus avisos.</div>';
      return;
    }

    el.innerHTML = remindersForQuote(quote).map(function(item){
      var date = fromISODate(item.date);
      var status = date < today() ? "Visto" : "Programado";
      var pillClass = date < today() ? "accepted" : (item.offset === 0 ? "expired" : "pending");
      return '<div class="timeline-item">'+
        '<div class="timeline-dot">'+(item.offset === 0 ? "V" : "-"+item.offset)+'</div>'+
        '<div class="timeline-copy"><strong>'+item.label+'</strong><span>'+item.type+' · '+formatDate(item.date)+'</span></div>'+
        '<span class="status-pill '+pillClass+'">'+status+'</span>'+
      '</div>';
    }).join("");
  }

  function renderCalendar(){
    var quote = getActiveQuote();
    var base = quote ? fromISODate(quote.dueAt) : today();
    var first = new Date(base.getFullYear(), base.getMonth(), 1);
    var startWeek = (first.getDay() + 6) % 7;
    var start = addDays(first, -startWeek);
    var reminders = quote ? remindersForQuote(quote) : [];
    var alertMap = {};
    reminders.forEach(function(r){
      alertMap[r.date] = r.offset === 0 ? "due" : "alert";
    });

    var html = "";
    for(var i=0;i<35;i++){
      var d = addDays(start, i);
      var iso = toISODate(d);
      var marker = alertMap[iso];
      var cls = marker === "due" ? "has-due" : (marker === "alert" ? "has-alert" : "");
      var text = marker === "due" ? "Vence" : (marker === "alert" ? "Aviso" : "");
      html += '<div class="client-day '+cls+'"><b>'+d.getDate()+'</b>'+text+'</div>';
    }
    $("#clientCalendar").innerHTML = html;
  }

  function createSimulatedQuote(){
    var n = state.quotes.length + 1;
    var now = today();
    var due = addDays(now, 15);
    var amount = 1450 + (n * 375);

    var quote = {
      id:"PRE-2026-" + String(n+1).padStart(3,"0"),
      title:"Presupuesto simulado #" + (n+1),
      issuedAt:toISODate(now),
      dueAt:toISODate(due),
      amount:amount,
      status:"pending",
      services:[
        ["Servicio estratégico", 1, Math.round(amount*0.45)],
        ["Implementación técnica", 1, Math.round(amount*0.38)],
        ["Formación y soporte", 1, amount - Math.round(amount*0.45) - Math.round(amount*0.38)]
      ]
    };

    state.quotes.unshift(quote);
    selectedQuoteId = quote.id;
    saveState();
    renderAll();
    toast("Presupuesto creado con avisos a 10 días, 5 días y 24 horas.");
  }

  function acceptQuote(id){
    var quote = state.quotes.find(function(q){ return q.id === id; });
    if(!quote) return;

    quote.status = "accepted";
    var inv = {
      id:"FAC-2026-" + String(state.invoices.length + 2).padStart(3,"0"),
      title:"Factura de " + quote.title,
      issuedAt:toISODate(today()),
      dueAt:toISODate(addDays(today(), 15)),
      amount:quote.amount,
      status:"unpaid",
      services:quote.services.slice()
    };
    state.invoices.unshift(inv);
    saveState();
    renderAll();
    toast("Presupuesto aceptado y factura creada.");
  }

  function expireQuote(id){
    var quote = state.quotes.find(function(q){ return q.id === id; });
    if(!quote) return;
    quote.status = "expired";
    quote.dueAt = toISODate(addDays(today(), -1));
    selectedQuoteId = id;
    saveState();
    renderAll();
    toast("Presupuesto marcado como vencido para la prueba.");
  }

  function payInvoice(id){
    var invoice = state.invoices.find(function(i){ return i.id === id; });
    if(!invoice) return;
    invoice.status = "paid";
    saveState();
    renderAll();
    toast("Factura marcada como pagada.");
  }

  function previewQuote(id){
    var quote = state.quotes.find(function(q){ return q.id === id; });
    if(!quote) return;
    openPreview("Presupuesto", quote, quoteStatus(quote));
  }

  function previewInvoice(id){
    var inv = state.invoices.find(function(i){ return i.id === id; });
    if(!inv) return;
    openPreview("Factura", inv, inv.status);
  }

  function openPreview(type, doc, status){
    var rows = doc.services.map(function(s){
      return '<tr><td>'+s[0]+'</td><td>'+s[1]+'</td><td>'+euro(s[2])+'</td><td>'+euro(Number(s[1])*Number(s[2]))+'</td></tr>';
    }).join("");

    $("#previewContent").innerHTML = ''+
      '<div class="preview-head">'+
        '<div><p class="eyebrow">'+type+'</p><h2>'+doc.id+'</h2><p>'+doc.title+'</p></div>'+
        '<div><span class="status-pill '+status+'">'+statusLabel(status)+'</span><p class="doc-meta">Emitido: '+formatDate(doc.issuedAt)+'<br>Vencimiento: '+formatDate(doc.dueAt)+'</p></div>'+
      '</div>'+
      '<p><b>Cliente:</b> '+state.client.name+' · '+state.client.email+'</p>'+
      '<table class="preview-table"><thead><tr><th>Concepto</th><th>Ud.</th><th>Precio</th><th>Total</th></tr></thead><tbody>'+rows+'</tbody></table>'+
      '<div class="preview-total">Total: '+euro(doc.amount)+'</div>'+
      '<div class="doc-actions">'+
        '<button class="tiny-btn primary" id="printPreviewBtn" type="button">Imprimir / guardar PDF</button>'+
      '</div>';

    $("#previewPanel").classList.add("is-open");
    $("#previewPanel").setAttribute("aria-hidden","false");

    $("#printPreviewBtn").addEventListener("click", function(){
      document.body.classList.add("printing");
      window.print();
      setTimeout(function(){ document.body.classList.remove("printing"); }, 300);
    });
  }

  function closePreview(){
    $("#previewPanel").classList.remove("is-open");
    $("#previewPanel").setAttribute("aria-hidden","true");
  }

  function downloadICS(){
    var quote = getActiveQuote();
    if(!quote){
      toast("Crea o selecciona un presupuesto primero.");
      return;
    }
    var ics = buildICS(quote);
    var blob = new Blob([ics], {type:"text/calendar;charset=utf-8"});
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = quote.id + "-avisos.ics";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 1000);
    toast("Calendario .ics generado.");
  }

  function yyyymmdd(date){
    var d = fromISODate(date);
    var y = d.getFullYear();
    var m = String(d.getMonth()+1).padStart(2,"0");
    var day = String(d.getDate()).padStart(2,"0");
    return ""+y+m+day;
  }

  function buildICS(quote){
    var uidBase = quote.id + "@dashboard-pymes-local";
    var due = yyyymmdd(quote.dueAt);
    var created = new Date().toISOString().replace(/[-:]/g,"").split(".")[0] + "Z";
    var summary = "Vence presupuesto " + quote.id;
    var description = "Presupuesto pendiente de aceptación por " + euro(quote.amount) + ". Avisos: 10 días, 5 días y 24 horas antes.";

    return [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Dashboard Pymes Local//Area Cliente//ES",
      "CALSCALE:GREGORIAN",
      "BEGIN:VEVENT",
      "UID:"+uidBase,
      "DTSTAMP:"+created,
      "DTSTART;VALUE=DATE:"+due,
      "SUMMARY:"+escapeICS(summary),
      "DESCRIPTION:"+escapeICS(description),
      "BEGIN:VALARM",
      "TRIGGER:-P10D",
      "ACTION:DISPLAY",
      "DESCRIPTION:"+escapeICS("Aviso: quedan 10 días para aceptar " + quote.id),
      "END:VALARM",
      "BEGIN:VALARM",
      "TRIGGER:-P5D",
      "ACTION:DISPLAY",
      "DESCRIPTION:"+escapeICS("Aviso: quedan 5 días para aceptar " + quote.id),
      "END:VALARM",
      "BEGIN:VALARM",
      "TRIGGER:-P1D",
      "ACTION:DISPLAY",
      "DESCRIPTION:"+escapeICS("Aviso: quedan 24 horas para aceptar " + quote.id),
      "END:VALARM",
      "END:VEVENT",
      "END:VCALENDAR"
    ].join("\\r\\n");
  }

  function escapeICS(text){
    return String(text).replace(/\\/g,"\\\\").replace(/;/g,"\\;").replace(/,/g,"\\,").replace(/\n/g,"\\n");
  }


  async function createCalendarApiEvent(){
    var quote = getActiveQuote();
    if(!quote){
      toast("Crea o selecciona un presupuesto primero.");
      return;
    }
    if(!window.CompanyIntegrations){
      toast("Módulo de integraciones no cargado.");
      return;
    }
    toast("Probando Google Calendar API...");
    var result = await window.CompanyIntegrations.createGoogleCalendarQuoteEvent(quote, state.client);
    toast(result.message);
  }

  async function sendGmailApiReminder(){
    var quote = getActiveQuote();
    if(!quote){
      toast("Crea o selecciona un presupuesto primero.");
      return;
    }
    if(!window.CompanyIntegrations){
      toast("Módulo de integraciones no cargado.");
      return;
    }
    toast("Probando Gmail API...");
    var result = await window.CompanyIntegrations.sendGmailQuoteReminder(quote, state.client);
    toast(result.message);
  }

  function resetDemo(){
    state = defaultState();
    selectedQuoteId = state.quotes[0] ? state.quotes[0].id : null;
    saveState();
    renderAll();
    toast("Demo restaurada.");
  }

  function toast(message){
    var existing = $(".toast");
    if(existing) existing.remove();
    var node = document.createElement("div");
    node.className = "toast";
    node.textContent = message;
    node.style.cssText = "position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);background:#0f172a;color:white;padding:12px 16px;border-radius:999px;z-index:999;font-weight:800;font-size:13px;box-shadow:0 12px 32px rgba(15,23,42,.22);max-width:calc(100% - 28px);text-align:center;";
    document.body.appendChild(node);
    setTimeout(function(){ if(node && node.parentNode) node.parentNode.removeChild(node); }, 2200);
  }

  function renderAll(){
    renderStatus();
    renderQuotes();
    renderInvoices();
    renderTimeline();
    renderCalendar();
  }

  function bindBaseEvents(){
    $("#createQuoteBtn").addEventListener("click", createSimulatedQuote);
    $("#downloadIcsBtn").addEventListener("click", downloadICS);
    var calendarApiBtn = $("#createCalendarApiBtn");
    if(calendarApiBtn) calendarApiBtn.addEventListener("click", createCalendarApiEvent);
    var gmailApiBtn = $("#sendGmailApiBtn");
    if(gmailApiBtn) gmailApiBtn.addEventListener("click", sendGmailApiReminder);
    $("#resetClientBtn").addEventListener("click", resetDemo);
    $("#closePreviewBtn").addEventListener("click", closePreview);
    $("#previewPanel").addEventListener("click", function(e){
      if(e.target === $("#previewPanel")) closePreview();
    });
    document.addEventListener("keydown", function(e){
      if(e.key === "Escape") closePreview();
    });
  }

  function init(){
    if(state.quotes[0]) selectedQuoteId = state.quotes[0].id;
    bindBaseEvents();
    renderAll();
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", init);
  }else{
    init();
  }
})();
