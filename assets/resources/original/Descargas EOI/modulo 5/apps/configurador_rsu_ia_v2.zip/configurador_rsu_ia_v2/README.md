# Configurador RSU IA V2

Versión corregida para móvil.

## Cambios
- Datos precargados: no abre vacío.
- Menú superior horizontal, no se monta encima del contenido.
- Las secciones ya no dependen de pestañas ocultas.
- Botones corregidos con eventos centralizados.
- Caso 2.000 t/día cargado por defecto.
- Informe, balances, costes y diagrama visibles desde el inicio.

## Uso
Abre `index.html` en Safari/Chrome, no solo en la vista previa de Archivos de iPhone.
