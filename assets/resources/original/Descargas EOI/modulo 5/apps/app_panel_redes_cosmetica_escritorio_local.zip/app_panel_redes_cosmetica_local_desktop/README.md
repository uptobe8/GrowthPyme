# Panel local redes · Cosmética coreana

Aplicación de escritorio local. No usa Streamlit ni servidor web.

## Abrir en Mac
Doble clic en `run_mac.command`.

Si macOS bloquea el archivo: botón derecho > Abrir.

## Abrir en Windows
Doble clic en `run_windows.bat`.

## Qué hace
- Lee el Excel incluido en `/data/panel_redes_cosmetica_coreana.xlsx`.
- Permite cargar otro Excel desde el botón `Cargar Excel`.
- Muestra KPIs, embudo, gráficos por red y cuentakilómetros.
- Calcula cuántos reels necesitas para ganar seguidores según el histórico real.
- No inventa el dato si no existen filas `Reel/TikTok` con `Nuevos seguidores`.

## Columnas necesarias
La app espera una hoja llamada `Datos_Redes` con estas columnas:

`Fecha`, `Red`, `Formato`, `Alcance`, `Clics web`, `Visitas web`, `Añadidos carrito`, `Compras`, `Ingresos €`, `Gasto Ads €`, `Nuevos seguidores`.

## Primer uso
El primer arranque instala librerías en una carpeta local `.venv`. Después abre más rápido.
