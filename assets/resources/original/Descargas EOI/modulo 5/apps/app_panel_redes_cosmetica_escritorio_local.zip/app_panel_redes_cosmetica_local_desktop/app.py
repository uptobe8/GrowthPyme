#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
App local de escritorio para leer redes sociales de un ecommerce de cosmética coreana.
Funciona en local con Tkinter. No usa Streamlit ni servidor web.
"""

from __future__ import annotations

import math
import os
import sys
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd

APP_TITLE = "Panel local redes · Cosmética coreana"
SHEET_DATA = "Datos_Redes"
SHEET_LEVERS = "Palancas"
DEFAULT_EXCEL = Path(__file__).resolve().parent / "data" / "panel_redes_cosmetica_coreana.xlsx"

COL_DATE = "Fecha"
COL_NETWORK = "Red"
COL_FORMAT = "Formato"
COL_REACH = "Alcance"
COL_IMPRESSIONS = "Impresiones"
COL_LIKES = "Likes"
COL_COMMENTS = "Comentarios"
COL_SAVES = "Guardados"
COL_SHARES = "Compartidos"
COL_CLICKS = "Clics web"
COL_VISITS = "Visitas web"
COL_CARTS = "Añadidos carrito"
COL_PURCHASES = "Compras"
COL_REVENUE = "Ingresos €"
COL_SPEND = "Gasto Ads €"
COL_NEW_FOLLOWERS = "Nuevos seguidores"

REQUIRED_COLUMNS = [
    COL_DATE, COL_NETWORK, COL_FORMAT, COL_REACH, COL_CLICKS, COL_VISITS,
    COL_CARTS, COL_PURCHASES, COL_REVENUE, COL_SPEND, COL_NEW_FOLLOWERS
]


def money(value: float) -> str:
    return f"{value:,.0f} €".replace(",", ".")


def integer(value: float) -> str:
    return f"{value:,.0f}".replace(",", ".")


def pct(value: float) -> str:
    return f"{value * 100:.1f}%".replace(".", ",")


def ratio(value: float) -> str:
    return f"{value:.2f}x".replace(".", ",")


def safe_div(num: float, den: float) -> float:
    if den in (0, None) or pd.isna(den):
        return 0.0
    return float(num) / float(den)


@dataclass
class Summary:
    reach: float = 0
    clicks: float = 0
    visits: float = 0
    carts: float = 0
    purchases: float = 0
    revenue: float = 0
    spend: float = 0
    new_followers: float = 0
    interactions: float = 0
    ctr: float = 0
    er: float = 0
    web_conversion: float = 0
    cart_rate: float = 0
    roas: float = 0
    cpa: float = 0
    ticket: float = 0
    reel_rows: int = 0
    followers_per_reel: float = 0


class PanelApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1280x820")
        self.minsize(1160, 760)

        self.df_raw = pd.DataFrame()
        self.df = pd.DataFrame()
        self.palancas = pd.DataFrame()
        self.summary = Summary()
        self.current_file = None

        self.network_var = tk.StringVar(value="Todas")
        self.goal_type_var = tk.StringVar(value="ganar")
        self.goal_followers_var = tk.StringVar(value="1000")
        self.current_followers_var = tk.StringVar(value="")
        self.reels_week_var = tk.StringVar(value="3")

        self._set_style()
        self._build_ui()
        if DEFAULT_EXCEL.exists():
            self.load_excel(DEFAULT_EXCEL)

    def _set_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#f7f4ef")
        style.configure("Card.TFrame", background="#ffffff", relief="flat")
        style.configure("TLabel", background="#f7f4ef", foreground="#151515", font=("Arial", 10))
        style.configure("Title.TLabel", font=("Arial", 20, "bold"), background="#f7f4ef")
        style.configure("Sub.TLabel", font=("Arial", 10), background="#f7f4ef", foreground="#555555")
        style.configure("Kpi.TLabel", font=("Arial", 18, "bold"), background="#ffffff", foreground="#151515")
        style.configure("KpiSmall.TLabel", font=("Arial", 9), background="#ffffff", foreground="#666666")
        style.configure("Warn.TLabel", font=("Arial", 10, "bold"), background="#ffffff", foreground="#9a3412")
        style.configure("Good.TLabel", font=("Arial", 10, "bold"), background="#ffffff", foreground="#166534")
        style.configure("TButton", font=("Arial", 10, "bold"), padding=8)
        style.configure("TNotebook", background="#f7f4ef", borderwidth=0)
        style.configure("TNotebook.Tab", padding=(16, 8), font=("Arial", 10, "bold"))
        style.configure("Treeview", font=("Arial", 9), rowheight=27)
        style.configure("Treeview.Heading", font=("Arial", 9, "bold"))

    def _build_ui(self):
        header = ttk.Frame(self)
        header.pack(fill="x", padx=18, pady=(14, 8))

        left = ttk.Frame(header)
        left.pack(side="left", fill="x", expand=True)
        ttk.Label(left, text="Panel local de redes sociales", style="Title.TLabel").pack(anchor="w")
        ttk.Label(left, text="Ecommerce de cosmética coreana · lectura simple + palancas de control", style="Sub.TLabel").pack(anchor="w")

        actions = ttk.Frame(header)
        actions.pack(side="right")
        ttk.Button(actions, text="Cargar Excel", command=self.pick_excel).pack(side="left", padx=4)
        ttk.Button(actions, text="Recargar", command=self.reload_current).pack(side="left", padx=4)

        filters = ttk.Frame(self)
        filters.pack(fill="x", padx=18, pady=(0, 8))
        ttk.Label(filters, text="Red:").pack(side="left")
        self.network_combo = ttk.Combobox(filters, textvariable=self.network_var, width=20, state="readonly", values=["Todas"])
        self.network_combo.pack(side="left", padx=(6, 16))
        self.network_combo.bind("<<ComboboxSelected>>", lambda _e: self.apply_filters())
        self.file_label = ttk.Label(filters, text="Archivo: —", style="Sub.TLabel")
        self.file_label.pack(side="left")

        self.warning_label = ttk.Label(self, text="", background="#fff7ed", foreground="#9a3412", font=("Arial", 10, "bold"))
        self.warning_label.pack(fill="x", padx=18, pady=(0, 8))

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        self.tab_dashboard = ttk.Frame(self.tabs)
        self.tab_reels = ttk.Frame(self.tabs)
        self.tab_palancas = ttk.Frame(self.tabs)
        self.tab_datos = ttk.Frame(self.tabs)

        self.tabs.add(self.tab_dashboard, text="Dashboard")
        self.tabs.add(self.tab_reels, text="Cuentakilómetros / Reels")
        self.tabs.add(self.tab_palancas, text="Palancas")
        self.tabs.add(self.tab_datos, text="Datos")

        self._build_dashboard_tab()
        self._build_reels_tab()
        self._build_palancas_tab()
        self._build_data_tab()

    def _build_dashboard_tab(self):
        top = ttk.Frame(self.tab_dashboard)
        top.pack(fill="x", padx=10, pady=10)
        self.kpi_widgets = {}
        for title in ["Alcance", "Clics", "Compras", "Ingresos", "ROAS", "Conversión web"]:
            card = ttk.Frame(top, style="Card.TFrame")
            card.pack(side="left", fill="x", expand=True, padx=5)
            ttk.Label(card, text=title, style="KpiSmall.TLabel").pack(anchor="w", padx=12, pady=(10, 0))
            value = ttk.Label(card, text="—", style="Kpi.TLabel")
            value.pack(anchor="w", padx=12, pady=(2, 12))
            self.kpi_widgets[title] = value

        body = ttk.Frame(self.tab_dashboard)
        body.pack(fill="both", expand=True, padx=10, pady=4)

        self.fig_main = plt.Figure(figsize=(11.7, 5.2), dpi=100)
        self.ax_funnel = self.fig_main.add_subplot(121)
        self.ax_network = self.fig_main.add_subplot(122)
        self.canvas_main = FigureCanvasTkAgg(self.fig_main, master=body)
        self.canvas_main.get_tk_widget().pack(fill="both", expand=True)

        bottom = ttk.Frame(self.tab_dashboard)
        bottom.pack(fill="x", padx=10, pady=8)
        self.reading_label = ttk.Label(bottom, text="", font=("Arial", 11, "bold"), background="#ffffff", foreground="#151515")
        self.reading_label.pack(fill="x", padx=5, pady=5)

    def _build_reels_tab(self):
        left = ttk.Frame(self.tab_reels)
        left.pack(side="left", fill="y", padx=14, pady=14)

        card = ttk.Frame(left, style="Card.TFrame")
        card.pack(fill="x", pady=(0, 10))
        ttk.Label(card, text="Cálculo de reels necesarios", style="Kpi.TLabel").pack(anchor="w", padx=14, pady=(14, 6))
        ttk.Label(card, text="Usa el promedio real: nuevos seguidores / reels publicados.", style="KpiSmall.TLabel").pack(anchor="w", padx=14, pady=(0, 10))

        form = ttk.Frame(card, style="Card.TFrame")
        form.pack(fill="x", padx=14, pady=8)
        ttk.Radiobutton(form, text="Quiero ganar X seguidores", variable=self.goal_type_var, value="ganar").grid(row=0, column=0, columnspan=2, sticky="w", pady=3)
        ttk.Radiobutton(form, text="Quiero llegar a un total", variable=self.goal_type_var, value="total").grid(row=1, column=0, columnspan=2, sticky="w", pady=3)
        ttk.Label(form, text="Seguidores actuales:", style="KpiSmall.TLabel").grid(row=2, column=0, sticky="w", pady=7)
        ttk.Entry(form, textvariable=self.current_followers_var, width=14).grid(row=2, column=1, sticky="w", pady=7)
        ttk.Label(form, text="Objetivo:", style="KpiSmall.TLabel").grid(row=3, column=0, sticky="w", pady=7)
        ttk.Entry(form, textvariable=self.goal_followers_var, width=14).grid(row=3, column=1, sticky="w", pady=7)
        ttk.Label(form, text="Reels/semana posibles:", style="KpiSmall.TLabel").grid(row=4, column=0, sticky="w", pady=7)
        ttk.Entry(form, textvariable=self.reels_week_var, width=14).grid(row=4, column=1, sticky="w", pady=7)
        ttk.Button(card, text="Calcular", command=self.update_all).pack(anchor="w", padx=14, pady=(6, 14))

        stats = ttk.Frame(left, style="Card.TFrame")
        stats.pack(fill="x")
        self.reels_result = ttk.Label(stats, text="—", style="Kpi.TLabel", wraplength=320)
        self.reels_result.pack(anchor="w", padx=14, pady=(14, 4))
        self.reels_basis = ttk.Label(stats, text="—", style="KpiSmall.TLabel", wraplength=330)
        self.reels_basis.pack(anchor="w", padx=14, pady=(0, 14))

        right = ttk.Frame(self.tab_reels)
        right.pack(side="right", fill="both", expand=True, padx=8, pady=14)
        self.fig_gauges = plt.Figure(figsize=(8.8, 6.2), dpi=100)
        self.ax_g1 = self.fig_gauges.add_subplot(231)
        self.ax_g2 = self.fig_gauges.add_subplot(232)
        self.ax_g3 = self.fig_gauges.add_subplot(233)
        self.ax_g4 = self.fig_gauges.add_subplot(234)
        self.ax_g5 = self.fig_gauges.add_subplot(235)
        self.ax_g6 = self.fig_gauges.add_subplot(236)
        self.canvas_gauges = FigureCanvasTkAgg(self.fig_gauges, master=right)
        self.canvas_gauges.get_tk_widget().pack(fill="both", expand=True)

    def _build_palancas_tab(self):
        top = ttk.Frame(self.tab_palancas)
        top.pack(fill="x", padx=10, pady=10)
        self.action_label = ttk.Label(top, text="", font=("Arial", 11, "bold"), background="#ffffff", foreground="#151515", wraplength=1100)
        self.action_label.pack(fill="x", padx=5, pady=5)

        table_frame = ttk.Frame(self.tab_palancas)
        table_frame.pack(fill="both", expand=True, padx=10, pady=8)
        cols = ("Métrica", "Señal", "Palanca", "Acción")
        self.lever_tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        for col, width in zip(cols, [130, 190, 180, 650]):
            self.lever_tree.heading(col, text=col)
            self.lever_tree.column(col, width=width, anchor="w")
        yscroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.lever_tree.yview)
        self.lever_tree.configure(yscrollcommand=yscroll.set)
        self.lever_tree.pack(side="left", fill="both", expand=True)
        yscroll.pack(side="right", fill="y")

    def _build_data_tab(self):
        frame = ttk.Frame(self.tab_datos)
        frame.pack(fill="both", expand=True, padx=10, pady=10)
        cols = ["Fecha", "Red", "Formato", "Alcance", "Clics web", "Compras", "Ingresos €", "Gasto Ads €", "Nuevos seguidores"]
        self.data_tree = ttk.Treeview(frame, columns=cols, show="headings")
        for col in cols:
            self.data_tree.heading(col, text=col)
            self.data_tree.column(col, width=130, anchor="w")
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=self.data_tree.yview)
        xscroll = ttk.Scrollbar(frame, orient="horizontal", command=self.data_tree.xview)
        self.data_tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.data_tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

    def pick_excel(self):
        file_path = filedialog.askopenfilename(
            title="Selecciona tu Excel de redes",
            filetypes=[("Excel", "*.xlsx *.xls")]
        )
        if file_path:
            self.load_excel(Path(file_path))

    def reload_current(self):
        if self.current_file:
            self.load_excel(self.current_file)
        elif DEFAULT_EXCEL.exists():
            self.load_excel(DEFAULT_EXCEL)

    def load_excel(self, path: Path):
        try:
            excel = pd.ExcelFile(path)
            if SHEET_DATA in excel.sheet_names:
                df = pd.read_excel(path, sheet_name=SHEET_DATA)
            else:
                df = pd.read_excel(path, sheet_name=0)

            palancas = pd.DataFrame()
            if SHEET_LEVERS in excel.sheet_names:
                palancas = pd.read_excel(path, sheet_name=SHEET_LEVERS, header=2)

        except Exception as exc:
            messagebox.showerror("No se pudo abrir el Excel", str(exc))
            return

        missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
        if missing:
            messagebox.showerror(
                "Columnas necesarias no encontradas",
                "Faltan estas columnas:\n" + "\n".join(missing)
            )
            return

        self.df_raw = self._clean_data(df)
        self.palancas = palancas.dropna(how="all") if not palancas.empty else pd.DataFrame()
        self.current_file = path
        self.file_label.configure(text=f"Archivo: {path.name}")
        self.refresh_networks()
        self.apply_filters()

    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out = out.dropna(how="all")
        out[COL_DATE] = pd.to_datetime(out[COL_DATE], errors="coerce")
        for col in [COL_REACH, COL_IMPRESSIONS, COL_LIKES, COL_COMMENTS, COL_SAVES, COL_SHARES,
                    COL_CLICKS, COL_VISITS, COL_CARTS, COL_PURCHASES, COL_REVENUE, COL_SPEND, COL_NEW_FOLLOWERS]:
            if col in out.columns:
                out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0)
        out[COL_NETWORK] = out[COL_NETWORK].astype(str).fillna("Sin red")
        out[COL_FORMAT] = out[COL_FORMAT].astype(str).fillna("Sin formato")
        return out

    def refresh_networks(self):
        networks = ["Todas"] + sorted([n for n in self.df_raw[COL_NETWORK].dropna().unique().tolist() if n and n != "nan"])
        self.network_combo.configure(values=networks)
        if self.network_var.get() not in networks:
            self.network_var.set("Todas")

    def apply_filters(self):
        if self.df_raw.empty:
            return
        if self.network_var.get() == "Todas":
            self.df = self.df_raw.copy()
        else:
            self.df = self.df_raw[self.df_raw[COL_NETWORK] == self.network_var.get()].copy()
        self.update_all()

    def summarize(self) -> Summary:
        df = self.df
        s = Summary()
        if df.empty:
            return s
        s.reach = df[COL_REACH].sum()
        s.clicks = df[COL_CLICKS].sum()
        s.visits = df[COL_VISITS].sum()
        s.carts = df[COL_CARTS].sum()
        s.purchases = df[COL_PURCHASES].sum()
        s.revenue = df[COL_REVENUE].sum()
        s.spend = df[COL_SPEND].sum()
        s.new_followers = df[COL_NEW_FOLLOWERS].sum()
        s.interactions = df[[c for c in [COL_LIKES, COL_COMMENTS, COL_SAVES, COL_SHARES] if c in df.columns]].sum().sum()
        s.ctr = safe_div(s.clicks, s.reach)
        s.er = safe_div(s.interactions, s.reach)
        s.web_conversion = safe_div(s.purchases, s.visits)
        s.cart_rate = safe_div(s.carts, s.visits)
        s.roas = safe_div(s.revenue, s.spend)
        s.cpa = safe_div(s.spend, s.purchases)
        s.ticket = safe_div(s.revenue, s.purchases)

        reels_mask = df[COL_FORMAT].str.contains("reel|tiktok", case=False, na=False)
        reels_df = df[reels_mask]
        s.reel_rows = int(len(reels_df))
        s.followers_per_reel = safe_div(reels_df[COL_NEW_FOLLOWERS].sum(), s.reel_rows)
        return s

    def update_all(self):
        self.summary = self.summarize()
        self.update_kpis()
        self.update_main_charts()
        self.update_reels()
        self.update_gauges()
        self.update_palancas()
        self.update_data_table()

    def update_kpis(self):
        s = self.summary
        values = {
            "Alcance": integer(s.reach),
            "Clics": integer(s.clicks),
            "Compras": integer(s.purchases),
            "Ingresos": money(s.revenue),
            "ROAS": ratio(s.roas) if s.spend > 0 else "—",
            "Conversión web": pct(s.web_conversion),
        }
        for k, v in values.items():
            self.kpi_widgets[k].configure(text=v)

        alerts = self.get_alerts()
        msg = "Lectura rápida: " + (" · ".join(alerts[:2]) if alerts else "el embudo no muestra alertas críticas con los datos cargados.")
        self.reading_label.configure(text=msg)

        if self.summary.reel_rows == 0:
            self.warning_label.configure(text="Aviso: no hay filas con formato Reel/TikTok. No se puede calcular seguidores por reel.")
        else:
            self.warning_label.configure(text="")

    def update_main_charts(self):
        df = self.df.copy()
        self.ax_funnel.clear()
        self.ax_network.clear()

        steps = ["Alcance", "Clics", "Carritos", "Compras"]
        values = [self.summary.reach, self.summary.clicks, self.summary.carts, self.summary.purchases]
        self.ax_funnel.barh(steps, values, color=["#d7ccc0", "#b58b6f", "#8f5d45", "#4b2e25"])
        self.ax_funnel.set_title("Embudo social → venta")
        self.ax_funnel.invert_yaxis()
        for idx, val in enumerate(values):
            self.ax_funnel.text(val, idx, "  " + integer(val), va="center", fontsize=9)
        self.ax_funnel.grid(axis="x", alpha=0.2)

        if not df.empty:
            grouped = df.groupby(COL_NETWORK, as_index=False).agg({COL_NEW_FOLLOWERS: "sum", COL_PURCHASES: "sum", COL_REVENUE: "sum"})
            labels = grouped[COL_NETWORK].tolist()
            x = range(len(labels))
            self.ax_network.bar(x, grouped[COL_NEW_FOLLOWERS], label="Nuevos seguidores", color="#c89b6c")
            self.ax_network.plot(x, grouped[COL_PURCHASES], marker="o", label="Compras", color="#1f2937")
            self.ax_network.set_xticks(list(x))
            self.ax_network.set_xticklabels(labels, rotation=30, ha="right")
            self.ax_network.set_title("Seguidores y compras por red")
            self.ax_network.legend(loc="best", fontsize=8)
            self.ax_network.grid(axis="y", alpha=0.2)
        else:
            self.ax_network.text(0.5, 0.5, "Sin datos", ha="center", va="center")

        self.fig_main.tight_layout()
        self.canvas_main.draw_idle()

    def _draw_gauge(self, ax, value: float, max_value: float, title: str, label: str, inverse: bool = False):
        ax.clear()
        ax.set_aspect("equal")
        ax.axis("off")
        if max_value <= 0:
            max_value = 1
        value = max(0, min(value, max_value))
        frac = value / max_value
        if inverse:
            frac_color = 1 - frac
        else:
            frac_color = frac
        if frac_color >= 0.75:
            color = "#166534"
        elif frac_color >= 0.45:
            color = "#ca8a04"
        else:
            color = "#b91c1c"

        bg = plt.Circle((0, 0), 1.0, transform=ax.transData._b, color="#eeeeee")
        ax.add_artist(bg)
        wedge_bg = matplotlib.patches.Wedge((0, 0), 1.0, 180, 360, width=0.28, color="#e5e7eb")
        ax.add_patch(wedge_bg)
        wedge = matplotlib.patches.Wedge((0, 0), 1.0, 180, 180 + 180 * frac, width=0.28, color=color)
        ax.add_patch(wedge)
        angle = math.radians(180 + 180 * frac)
        ax.plot([0, 0.72 * math.cos(angle)], [0, 0.72 * math.sin(angle)], color="#111827", linewidth=3)
        ax.scatter([0], [0], s=25, color="#111827")
        ax.text(0, -0.20, label, ha="center", va="center", fontsize=15, fontweight="bold")
        ax.text(0, -0.48, title, ha="center", va="center", fontsize=9)
        ax.set_xlim(-1.15, 1.15)
        ax.set_ylim(-0.65, 1.15)

    def update_gauges(self):
        s = self.summary
        self._draw_gauge(self.ax_g1, s.er, 0.08, "Engagement", pct(s.er))
        self._draw_gauge(self.ax_g2, s.ctr, 0.025, "CTR a tienda", pct(s.ctr))
        self._draw_gauge(self.ax_g3, s.web_conversion, 0.04, "Conversión web", pct(s.web_conversion))
        self._draw_gauge(self.ax_g4, s.roas, 4.0, "ROAS", ratio(s.roas) if s.spend > 0 else "—")
        self._draw_gauge(self.ax_g5, s.cart_rate, 0.15, "Carrito/visitas", pct(s.cart_rate))
        self._draw_gauge(self.ax_g6, s.followers_per_reel, 20, "Seguidores por reel", f"{s.followers_per_reel:.1f}")
        self.fig_gauges.tight_layout()
        self.canvas_gauges.draw_idle()

    def update_reels(self):
        s = self.summary
        if s.reel_rows <= 0 or s.followers_per_reel <= 0:
            self.reels_result.configure(text="No se puede estimar")
            self.reels_basis.configure(text="Faltan datos reales de Reel/TikTok con nuevos seguidores. Añade filas con Formato = Reel/TikTok y Nuevos seguidores.")
            return

        try:
            goal = float(str(self.goal_followers_var.get()).replace(".", "").replace(",", "."))
        except ValueError:
            self.reels_result.configure(text="Objetivo no válido")
            self.reels_basis.configure(text="Introduce un número.")
            return

        if self.goal_type_var.get() == "total":
            try:
                current = float(str(self.current_followers_var.get()).replace(".", "").replace(",", "."))
            except ValueError:
                self.reels_result.configure(text="Falta seguidores actuales")
                self.reels_basis.configure(text="Para objetivo total necesito que indiques seguidores actuales.")
                return
            missing = max(0, goal - current)
        else:
            missing = max(0, goal)

        reels_needed = math.ceil(missing / s.followers_per_reel) if missing > 0 else 0
        try:
            reels_week = max(1, float(str(self.reels_week_var.get()).replace(",", ".")))
        except ValueError:
            reels_week = 3
        weeks = math.ceil(reels_needed / reels_week) if reels_needed else 0

        self.reels_result.configure(text=f"{reels_needed} reels aprox.")
        self.reels_basis.configure(
            text=(
                f"Base real: {s.reel_rows} reels detectados · "
                f"{s.followers_per_reel:.1f} seguidores/reel · "
                f"ritmo estimado: {weeks} semanas si publicas {reels_week:g} reels/semana."
            )
        )

    def get_alerts(self):
        s = self.summary
        alerts = []
        if s.ctr < 0.008:
            alerts.append("CTR bajo: cambia gancho, CTA y enlace directo a producto/rutina.")
        if s.web_conversion < 0.015:
            alerts.append("Conversión baja: revisa ficha, reseñas, precio, envío y packs.")
        if s.er < 0.03:
            alerts.append("Engagement bajo: más contenido educativo guardable y problemas concretos de piel.")
        if s.spend > 0 and s.roas < 2:
            alerts.append("ROAS bajo: no escales anuncios; prueba UGC, reseñas y productos con más margen.")
        if s.visits > 0 and s.cart_rate < 0.05:
            alerts.append("Pocos carritos: oferta o propuesta de valor poco clara.")
        if s.followers_per_reel <= 1 and s.reel_rows > 0:
            alerts.append("Los reels están captando pocos seguidores: crea series fijas y CTA de seguir.")
        return alerts

    def update_palancas(self):
        for item in self.lever_tree.get_children():
            self.lever_tree.delete(item)

        alerts = self.get_alerts()
        if alerts:
            self.action_label.configure(text="Acción prioritaria: " + alerts[0])
        else:
            self.action_label.configure(text="Acción prioritaria: mantener lo que funciona y escalar formatos con compras, guardados y nuevos seguidores.")

        if not self.palancas.empty and all(c in self.palancas.columns for c in ["Métrica", "Señal mala", "Palanca directa", "Acción concreta en cosmética coreana"]):
            for _, row in self.palancas.iterrows():
                self.lever_tree.insert("", "end", values=(
                    str(row.get("Métrica", "")),
                    str(row.get("Señal mala", "")),
                    str(row.get("Palanca directa", "")),
                    str(row.get("Acción concreta en cosmética coreana", "")),
                ))
        else:
            fallback = [
                ("CTR", "< 0,8%", "CTA + destino", "Enlace directo a producto/rutina, no a la home."),
                ("Conversión", "< 1,5%", "Ficha + confianza", "Añadir reseñas, modo de uso, textura, beneficios y envío claro."),
                ("Engagement", "< 3%", "Tema + utilidad", "Carruseles guardables: rutina, ingredientes, errores y comparativas."),
                ("ROAS", "< 2x", "Creatividad + margen", "Pausar anuncios fríos y probar UGC/reseñas con productos de margen."),
                ("Seguidores", "Reels sin seguidores", "Serie fija", "Crear series: piel coreana paso a paso, ingrediente de la semana."),
            ]
            for row in fallback:
                self.lever_tree.insert("", "end", values=row)

    def update_data_table(self):
        for item in self.data_tree.get_children():
            self.data_tree.delete(item)
        if self.df.empty:
            return
        cols = ["Fecha", "Red", "Formato", "Alcance", "Clics web", "Compras", "Ingresos €", "Gasto Ads €", "Nuevos seguidores"]
        show = self.df[cols].tail(150).copy()
        for _, row in show.iterrows():
            fecha = row["Fecha"].strftime("%Y-%m-%d") if pd.notna(row["Fecha"]) else ""
            self.data_tree.insert("", "end", values=(
                fecha,
                row["Red"],
                row["Formato"],
                integer(row["Alcance"]),
                integer(row["Clics web"]),
                integer(row["Compras"]),
                money(row["Ingresos €"]),
                money(row["Gasto Ads €"]),
                integer(row["Nuevos seguidores"]),
            ))


def main():
    app = PanelApp()
    app.mainloop()


if __name__ == "__main__":
    main()
