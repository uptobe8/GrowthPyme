(function(){
  "use strict";

  var CONFIG_KEY = "dashboard-pymes-integrations-v1";
  var LOG_KEY = "dashboard-pymes-integrations-log-v1";
  var DASHBOARD_KEY = "dashboard-pymes-local-v1";

  var API_CATALOG = [
    {
      id:"google-calendar",
      title:"Google Calendar API",
      use:"Crear eventos de vencimiento de presupuestos y recordatorios a 10 días, 5 días y 24 horas.",
      scopes:"https://www.googleapis.com/auth/calendar.events",
      endpoint:"POST https://www.googleapis.com/calendar/v3/calendars/{calendarId}/events",
      freeNote:"API pública de Google. Normalmente se puede usar con cuota gratuita, sujeta a límites y a la configuración de un proyecto OAuth."
    },
    {
      id:"gmail",
      title:"Gmail API",
      use:"Enviar emails de aviso de aceptación de presupuesto al cliente.",
      scopes:"https://www.googleapis.com/auth/gmail.send",
      endpoint:"POST https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
      freeNote:"API pública de Google. Requiere autorización del usuario de Gmail y consentimiento OAuth."
    },
    {
      id:"hubspot",
      title:"HubSpot CRM API",
      use:"Traer contactos, deals/negocios e importes para alimentar métricas del panel.",
      scopes:"crm.objects.contacts.read, crm.objects.deals.read, crm.objects.companies.read",
      endpoint:"GET https://api.hubapi.com/crm/v3/objects/{contacts|deals|companies}",
      freeNote:"API pública. Se puede probar con cuenta/CRM gratuito y token autorizado; las condiciones pueden cambiar."
    }
  ];

  var HUBSPOT_MAPPING = [
    ["HubSpot Deals amount", "facturacionActual", "Suma de importes de negocios activos/cerrados"],
    ["HubSpot Deals count", "ventas / clientesConseguidos", "Número de ventas o negocios detectados"],
    ["HubSpot Contacts count", "contactos", "Oportunidades o contactos comerciales"],
    ["HubSpot Contacts recientes", "clientesNuevos", "Clientes o contactos nuevos del periodo"],
    ["HubSpot Deals por etapa", "embudo de ventas", "Visitas → contactos → llamadas → presupuestos → ventas"],
    ["HubSpot Deals + inversión manual", "coste por cliente", "Inversión dividida entre clientes conseguidos"]
  ];

  function getConfig(){
    try{
      return Object.assign({googleCalendarId:"primary", googleAccessToken:"", gmailRecipient:"", hubspotAccessToken:"", proxyBaseUrl:""}, JSON.parse(localStorage.getItem(CONFIG_KEY) || "{}"));
    }catch(e){
      return {googleCalendarId:"primary", googleAccessToken:"", gmailRecipient:"", hubspotAccessToken:"", proxyBaseUrl:""};
    }
  }

  function saveConfig(config){
    localStorage.setItem(CONFIG_KEY, JSON.stringify(Object.assign({}, getConfig(), config || {})));
    addLog("Configuración guardada localmente.", "config");
  }

  function clearConfig(){
    localStorage.removeItem(CONFIG_KEY);
    addLog("Configuración borrada.", "config");
  }

  function addLog(message, type){
    var logs = getLogs();
    logs.unshift({message:message, type:type || "info", at:new Date().toISOString()});
    localStorage.setItem(LOG_KEY, JSON.stringify(logs.slice(0,30)));
  }

  function getLogs(){
    try{return JSON.parse(localStorage.getItem(LOG_KEY) || "[]");}catch(e){return [];}
  }

  function escapeHtml(value){
    return String(value == null ? "" : value).replace(/[&<>'"]/g, function(ch){
      return {"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch];
    });
  }

  function euro(value){
    return Number(value || 0).toLocaleString("es-ES", {maximumFractionDigits:0}) + " €";
  }

  function proxyUrl(path){
    var base = (getConfig().proxyBaseUrl || "").replace(/\/+$/, "");
    return base ? base + path : "";
  }

  function toDateOnly(date){
    var d = new Date(date);
    return d.toISOString().slice(0,10);
  }

  function addDays(date, days){
    var d = new Date(date);
    d.setDate(d.getDate()+days);
    return d;
  }

  function quoteToCalendarEvent(quote, client){
    var due = quote && quote.dueAt ? quote.dueAt : toDateOnly(addDays(new Date(), 15));
    var next = toDateOnly(addDays(due, 1));
    var title = quote && quote.id ? "Vence presupuesto " + quote.id : "Vence presupuesto";
    var description = "Aviso de aceptación de presupuesto. Cliente: " + ((client && client.name) || "Cliente") + ". Importe: " + euro(quote && quote.amount);

    return {
      summary:title,
      description:description,
      start:{date:due},
      end:{date:next},
      reminders:{
        useDefault:false,
        overrides:[
          {method:"popup", minutes:14400},
          {method:"popup", minutes:7200},
          {method:"popup", minutes:1440}
        ]
      }
    };
  }

  function base64Url(str){
    var utf8 = unescape(encodeURIComponent(str));
    return btoa(utf8).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
  }

  async function createGoogleCalendarQuoteEvent(quote, client){
    var config = getConfig();
    if(!config.googleAccessToken){
      addLog("Google Calendar no ejecutado: falta access token temporal.", "calendar");
      return {ok:false, message:"Falta Google OAuth access token temporal. Configúralo en Integraciones API."};
    }
    var calendarId = encodeURIComponent(config.googleCalendarId || "primary");
    var payload = quoteToCalendarEvent(quote, client);
    var proxy = proxyUrl("/calendar/quote-event");
    if(proxy){
      var proxyRes = await fetch(proxy, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({quote:quote, client:client, calendarId:config.googleCalendarId || "primary", event:payload})
      });
      if(!proxyRes.ok){
        addLog("Error endpoint puente Calendar.", "calendar");
        return {ok:false, message:"El endpoint puente de Calendar devolvió error."};
      }
      addLog("Evento enviado al endpoint puente de Calendar para "+(quote && quote.id ? quote.id : "presupuesto demo")+".", "calendar");
      return {ok:true, message:"Evento enviado al endpoint puente de Calendar."};
    }
    var res = await fetch("https://www.googleapis.com/calendar/v3/calendars/"+calendarId+"/events", {
      method:"POST",
      headers:{"Authorization":"Bearer "+config.googleAccessToken, "Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    if(!res.ok){
      var txt = await res.text();
      addLog("Error Google Calendar: "+txt.slice(0,160), "calendar");
      return {ok:false, message:"Google Calendar devolvió error. Revisa token, permisos y Calendar ID."};
    }
    addLog("Evento creado en Google Calendar para "+(quote && quote.id ? quote.id : "presupuesto demo")+".", "calendar");
    return {ok:true, message:"Evento creado en Google Calendar."};
  }

  async function sendGmailQuoteReminder(quote, client){
    var config = getConfig();
    var to = config.gmailRecipient || (client && client.email) || "";
    var subject = "Recordatorio: presupuesto pendiente de aceptación";
    var body = "Hola,\n\nTe recordamos que el presupuesto " + ((quote && quote.id) || "") + " vence el " + ((quote && quote.dueAt) || "próximamente") + ".\n\nImporte: " + euro(quote && quote.amount) + "\n\nGracias.";

    var proxy = proxyUrl("/gmail/quote-reminder");
    if(proxy){
      var proxyRes = await fetch(proxy, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({quote:quote, client:client, to:to, subject:subject, body:body})
      });
      if(!proxyRes.ok){
        addLog("Error endpoint puente Gmail.", "gmail");
        return {ok:false, message:"El endpoint puente de Gmail devolvió error."};
      }
      addLog("Aviso enviado al endpoint puente Gmail para "+((quote && quote.id) || "presupuesto demo")+".", "gmail");
      return {ok:true, message:"Aviso enviado al endpoint puente Gmail."};
    }

    if(!config.googleAccessToken){
      var gmailCompose = "https://mail.google.com/mail/?view=cm&fs=1&to="+encodeURIComponent(to)+"&su="+encodeURIComponent(subject)+"&body="+encodeURIComponent(body);
      addLog("Gmail API no ejecutado: falta access token. Abriendo composición Gmail como fallback.", "gmail");
      if(typeof window !== "undefined") window.open(gmailCompose, "_blank");
      return {ok:false, message:"Falta token Gmail API. He abierto Gmail en modo composición si el navegador lo permite."};
    }
    if(!to){
      return {ok:false, message:"Falta email destino para enviar el aviso."};
    }
    var raw = base64Url("To: "+to+"\r\nSubject: "+subject+"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n"+body);
    var res = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
      method:"POST",
      headers:{"Authorization":"Bearer "+config.googleAccessToken, "Content-Type":"application/json"},
      body:JSON.stringify({raw:raw})
    });
    if(!res.ok){
      var txt = await res.text();
      addLog("Error Gmail API: "+txt.slice(0,160), "gmail");
      return {ok:false, message:"Gmail API devolvió error. Revisa token y scope gmail.send."};
    }
    addLog("Email enviado con Gmail API para "+((quote && quote.id) || "presupuesto demo")+".", "gmail");
    return {ok:true, message:"Aviso enviado por Gmail API."};
  }

  function readDashboardState(){
    var defaults = (typeof window !== "undefined" && window.DEFAULT_STATE) ? window.DEFAULT_STATE : {};
    try{return Object.assign({}, defaults, JSON.parse(localStorage.getItem(DASHBOARD_KEY) || "{}"));}catch(e){return Object.assign({}, defaults);}
  }

  function writeDashboardState(patch){
    var current = readDashboardState();
    localStorage.setItem(DASHBOARD_KEY, JSON.stringify(Object.assign({}, current, patch || {})));
  }

  function simulateHubSpotImport(){
    var simulated = {
      facturacionActual: 18650,
      objetivoMinimo: 15000,
      objetivoBueno: 22000,
      contactos: 214,
      llamadas: 96,
      presupuestos: 52,
      ventas: 27,
      clientesConseguidos: 27,
      clientesNuevos: 42,
      clientesRecurrentes: 58,
      inversionCampanas: 1640,
      ticketMedio: 691
    };
    writeDashboardState(simulated);
    addLog("Simulación HubSpot aplicada al dashboard: 214 contactos, 52 presupuestos, 27 ventas.", "hubspot");
    return {ok:true, message:"Datos simulados de HubSpot aplicados. Vuelve al dashboard para verlos.", data:simulated};
  }

  async function pullHubSpotDashboardData(){
    var config = getConfig();
    var proxy = proxyUrl("/hubspot/dashboard-snapshot");
    if(proxy){
      var proxyRes = await fetch(proxy, {headers:{"Content-Type":"application/json"}});
      if(!proxyRes.ok){
        addLog("Error endpoint puente HubSpot.", "hubspot");
        return {ok:false, message:"El endpoint puente de HubSpot devolvió error."};
      }
      var proxyData = await proxyRes.json();
      var mappedProxy = proxyData.dashboard || proxyData;
      writeDashboardState(mappedProxy);
      addLog("Datos importados desde endpoint puente HubSpot.", "hubspot");
      return {ok:true, message:"Datos importados desde endpoint puente HubSpot.", data:mappedProxy};
    }
    if(!config.hubspotAccessToken){
      addLog("HubSpot API no ejecutado: falta access token temporal.", "hubspot");
      return {ok:false, message:"Falta HubSpot access token temporal. Configúralo en Integraciones API."};
    }
    var headers = {"Authorization":"Bearer "+config.hubspotAccessToken, "Content-Type":"application/json"};
    var dealsUrl = "https://api.hubapi.com/crm/v3/objects/deals?limit=100&properties=amount,dealstage,closedate,createdate";
    var contactsUrl = "https://api.hubapi.com/crm/v3/objects/contacts?limit=100&properties=createdate,lastmodifieddate,email";
    var dealsRes = await fetch(dealsUrl, {headers:headers});
    var contactsRes = await fetch(contactsUrl, {headers:headers});
    if(!dealsRes.ok || !contactsRes.ok){
      addLog("Error HubSpot API. Puede ser token, permisos o CORS en navegador local.", "hubspot");
      return {ok:false, message:"HubSpot API devolvió error. En producción usa endpoint puente para no exponer tokens."};
    }
    var deals = await dealsRes.json();
    var contacts = await contactsRes.json();
    var dealRows = deals.results || [];
    var contactRows = contacts.results || [];
    var totalAmount = dealRows.reduce(function(sum, deal){return sum + Number((deal.properties && deal.properties.amount) || 0);},0);
    var mapped = {
      facturacionActual: Math.round(totalAmount),
      contactos: contactRows.length,
      presupuestos: dealRows.length,
      ventas: dealRows.length,
      clientesConseguidos: dealRows.length,
      ticketMedio: dealRows.length ? Math.round(totalAmount/dealRows.length) : 0
    };
    writeDashboardState(mapped);
    addLog("HubSpot API importado: "+contactRows.length+" contactos y "+dealRows.length+" deals.", "hubspot");
    return {ok:true, message:"Datos de HubSpot importados al dashboard.", data:mapped};
  }

  function testQuote(){
    var now = new Date();
    return {
      id:"PRE-DEMO-API",
      title:"Presupuesto demo API",
      issuedAt:toDateOnly(now),
      dueAt:toDateOnly(addDays(now, 15)),
      amount:2450,
      status:"pending"
    };
  }

  window.CompanyIntegrations = {
    apiCatalog:API_CATALOG,
    hubspotMapping:HUBSPOT_MAPPING,
    getConfig:getConfig,
    saveConfig:saveConfig,
    clearConfig:clearConfig,
    getLogs:getLogs,
    addLog:addLog,
    escapeHtml:escapeHtml,
    quoteToCalendarEvent:quoteToCalendarEvent,
    createGoogleCalendarQuoteEvent:createGoogleCalendarQuoteEvent,
    sendGmailQuoteReminder:sendGmailQuoteReminder,
    simulateHubSpotImport:simulateHubSpotImport,
    pullHubSpotDashboardData:pullHubSpotDashboardData,
    testQuote:testQuote
  };
})();
