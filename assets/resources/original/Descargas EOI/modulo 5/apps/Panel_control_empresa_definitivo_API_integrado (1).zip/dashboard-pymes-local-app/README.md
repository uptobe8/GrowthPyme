# Dashboard Decisiones Pyme

App local en HTML, CSS y JavaScript para explicar métricas empresariales con la lógica:

Dato → Umbral → Color → Decisión

## Cómo abrirla

1. Descomprime la carpeta `dashboard-pymes-local-app`.
2. Abre `index.html`.
3. Funciona sin internet y sin instalar librerías.

## Compatibilidad

- Ordenador: abrir `index.html` en Chrome, Safari, Edge o Firefox.
- Android: abrir `index.html` desde Archivos, Chrome o navegador compatible.
- iPhone/iPad: descomprimir en Archivos y abrir `index.html`. Si la vista previa no ejecuta JavaScript, usar compartir/abrir con Safari.

## Archivos

- `index.html`: entrada principal.
- `assets/css/styles.css`: diseño responsive.
- `assets/js/data.js`: datos base, campos y catálogo de métricas.
- `assets/js/app.js`: cálculos, gráficas y navegación.
- `manifest.webmanifest`: configuración PWA cuando se sirve desde navegador.
- `service-worker.js`: caché offline cuando se usa desde http/https.

## Notas

La app no envía datos. El botón de guardar usa almacenamiento local del navegador cuando está disponible.

## Área privada de cliente

Nueva página independiente:

- `cliente.html`: portal local del cliente.
- `assets/js/client-area.js`: lógica de presupuestos, facturas, simulación, avisos y calendario.

Incluye:

- Presupuestos visibles para el cliente.
- Facturas visibles para el cliente.
- Botón para crear un presupuesto simulado.
- Avisos calculados a 10 días, 5 días y 24 horas antes del vencimiento.
- Calendario visual de avisos y vencimientos.
- Exportación `.ics` para probar los avisos en apps de calendario compatibles.
- Visualización de presupuesto/factura e impresión/guardar como PDF desde el navegador.

Limitación de la demo local: no envía emails, WhatsApp ni push reales. Para producción se debe conectar con backend, base de datos, autenticación y sistema de notificaciones.


## Integraciones API añadidas

Nueva página independiente:

- `integraciones.html`: centro de conexión para Google Calendar, Gmail y HubSpot.
- `assets/js/integrations.js`: capa común de APIs, configuración local, logs y simulación.
- `assets/js/integrations-page.js`: interfaz de configuración y pruebas.

APIs previstas:

- Google Calendar API: crear eventos de vencimiento de presupuestos con recordatorios a 10 días, 5 días y 24 horas. Scope: `https://www.googleapis.com/auth/calendar.events`.
- Gmail API: enviar avisos de aceptación de presupuesto. Scope: `https://www.googleapis.com/auth/gmail.send`.
- HubSpot CRM API: leer contactos, deals y empresas para alimentar el panel. Scopes de lectura CRM.

La app mantiene modo offline y simulación. Para llamadas reales se debe configurar un access token temporal o un endpoint puente propio. No se incluyen credenciales ni tokens dentro del ZIP.

Limitación técnica: una app HTML local no debe guardar tokens permanentes ni secretos de HubSpot/Gmail/Google en el frontend. Para producción real conviene usar backend/endpoint puente, OAuth y almacenamiento seguro.
