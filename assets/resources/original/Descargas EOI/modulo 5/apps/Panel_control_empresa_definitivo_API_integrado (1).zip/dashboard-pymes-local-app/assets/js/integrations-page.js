(function(){
  "use strict";
  var I = window.CompanyIntegrations;
  function $(selector){return document.querySelector(selector);}
  function $all(selector){return Array.prototype.slice.call(document.querySelectorAll(selector));}
  function toast(message){
    var existing = document.querySelector(".toast");
    if(existing) existing.remove();
    var node = document.createElement("div");
    node.className = "toast";
    node.textContent = message;
    node.style.cssText = "position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);background:#0f172a;color:white;padding:12px 16px;border-radius:999px;z-index:999;font-weight:800;font-size:13px;box-shadow:0 12px 32px rgba(15,23,42,.22);max-width:calc(100% - 28px);text-align:center;";
    document.body.appendChild(node);
    setTimeout(function(){ if(node && node.parentNode) node.parentNode.removeChild(node); }, 2600);
  }
  function renderApiStack(){
    $("#apiStack").innerHTML = I.apiCatalog.map(function(api){
      return '<article><span>'+I.escapeHtml(api.title)+'</span><strong>'+I.escapeHtml(api.id.replace('-', ' '))+'</strong></article>';
    }).join("");
  }
  function renderCatalog(){
    $("#apiCatalog").innerHTML = I.apiCatalog.map(function(api){
      return '<article class="api-card">'+
        '<h3>'+I.escapeHtml(api.title)+'</h3>'+
        '<p>'+I.escapeHtml(api.use)+'</p>'+
        '<div><b>Scope:</b><code>'+I.escapeHtml(api.scopes)+'</code></div>'+
        '<div><b>Endpoint:</b><code>'+I.escapeHtml(api.endpoint)+'</code></div>'+
        '<small>'+I.escapeHtml(api.freeNote)+'</small>'+
      '</article>';
    }).join("");
  }
  function renderForm(){
    var config = I.getConfig();
    Object.keys(config).forEach(function(key){
      var input = document.querySelector('[name="'+key+'"]');
      if(input) input.value = config[key] || "";
    });
  }
  function saveForm(){
    var data = {};
    $all("#integrationForm input").forEach(function(input){data[input.name] = input.value.trim();});
    I.saveConfig(data);
    renderLog();
    toast("Configuración guardada localmente.");
  }
  function clearForm(){
    I.clearConfig();
    renderForm();
    renderLog();
    toast("Configuración borrada.");
  }
  function renderMapping(){
    $("#mappingTable").innerHTML = '<table class="api-table"><thead><tr><th>Origen</th><th>Campo panel</th><th>Uso</th></tr></thead><tbody>'+
      I.hubspotMapping.map(function(row){
        return '<tr><td>'+I.escapeHtml(row[0])+'</td><td><code>'+I.escapeHtml(row[1])+'</code></td><td>'+I.escapeHtml(row[2])+'</td></tr>';
      }).join("")+
    '</tbody></table>';
  }
  function renderLog(){
    var logs = I.getLogs();
    if(!logs.length){
      $("#integrationLog").innerHTML = '<div class="empty-state">Sin eventos todavía.</div>';
      return;
    }
    $("#integrationLog").innerHTML = logs.slice(0,10).map(function(log){
      var date = new Date(log.at).toLocaleString("es-ES", {day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit"});
      return '<article class="log-item"><span class="status-pill '+I.escapeHtml(log.type)+'">'+I.escapeHtml(log.type)+'</span><p>'+I.escapeHtml(log.message)+'</p><small>'+date+'</small></article>';
    }).join("");
  }
  function bind(){
    $("#saveIntegrationConfigBtn").addEventListener("click", saveForm);
    $("#clearIntegrationConfigBtn").addEventListener("click", clearForm);
    $("#simulateHubspotBtn").addEventListener("click", function(){
      var result = I.simulateHubSpotImport();
      renderLog();
      toast(result.message);
    });
    $("#pullHubspotBtn").addEventListener("click", async function(){
      toast("Probando HubSpot API...");
      var result = await I.pullHubSpotDashboardData();
      renderLog();
      toast(result.message);
    });
    $("#testCalendarBtn").addEventListener("click", async function(){
      toast("Probando Google Calendar API...");
      var result = await I.createGoogleCalendarQuoteEvent(I.testQuote(), {name:"Cliente Demo", email:I.getConfig().gmailRecipient});
      renderLog();
      toast(result.message);
    });
    $("#testGmailBtn").addEventListener("click", async function(){
      toast("Probando Gmail API...");
      var result = await I.sendGmailQuoteReminder(I.testQuote(), {name:"Cliente Demo", email:I.getConfig().gmailRecipient});
      renderLog();
      toast(result.message);
    });
  }
  function init(){
    renderApiStack();
    renderCatalog();
    renderForm();
    renderMapping();
    renderLog();
    bind();
  }
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
